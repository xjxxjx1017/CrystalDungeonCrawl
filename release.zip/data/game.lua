require 'code/class'
require 'code/co'
require 'code/util'
require 'code/keycode'
require 'code/tweenmanager'
require 'units/player'
require 'units/unit_factory'
require 'units/unit_master'
require 'units/effect'
require 'equipments/equipment_def'
require 'equipments/equipment'

Chapters = {
    {
        intro = { '你醒来了，', '四周是很危险的丛林，', '你听到了附近黏黏的声音。', '现在的你虚弱而弱小，', '你感到心里升起一股热情', '（合成点什么来保护你自己吧）' },
        introBtn = '开始',
        clear = {'前面时一片森林，', '水晶力从茂密的丛林中蓬勃而出，', '那里会有些水晶矿吗？', '远处好像有什么巨大的东西', '正在逼近...'},
        clearBtn = '继续',
        lose = {'冰冷的黑暗将你吞没，', '没想到这片草地跟绵羊就这样成了你心里最后的景象。', '黑暗渐渐扩大，只留下最后一点小小的火焰', '（合成升级武器和护盾会让游戏更容易)'},
        loseBtn = '结束',
        mapData = nil,
    }
}

for i = 2, 19 do
    table.insert( Chapters, 
    {
        intro = {},
        introBtn = '',
        clear = {'关卡'..i, '（期待下一关吧）'},
        clearBtn = ' 继续 ',
        lose = {'关卡'..i, '失败'},
        loseBtn = '结束',
        mapData = nil,
    })
end

table.insert( Chapters, 
{
    intro = {},
    introBtn = '',
    clear = {'你成功了，走出了这片森林，', '这也许只是小小的第一步。', '但是世界的广大，纷繁奇异。', '又有多少未知的奇遇在前方等待。', '夜很长，一切才刚刚开始。', '（期待下一关吧）'},
    clearBtn = '胜利',
    lose = {'冰冷的黑暗将你吞没，', '没想到这片潮湿的森林就这样成了你心里最后的景象。', '黑暗渐渐扩大，不久什么都看不见了', '丛林深处巨大的黑影依稀可见', ''},
    loseBtn = '结束',
    mapData = nil,
})

Game = class({
    curUnitList = {},
    curEffectList = {},
    curStaticUnitList = {},
    
    coreLoop = nil,
    yard = nil,
    yardOriginal = nil,
    yard_ai = nil,
    player = nil,
	goal = nil,

    hint = nil,
    whitestar = nil,
    blind = nil,

    disableRange = 7,
    invisibleRange = 16,

    turn = 1,

    board = {},

    currency = copy( CRYSTALS ),
    weapon = Equipment.new( EQUIPMENT_DEFAULT ),
    shield = Equipment.new( EQUIPMENT_DEFAULT ),
    craftedEquipments = {},

    currentMapIndex = 0,

    uiDirty = false,

    ctor = function( self )
        self.currentMapIndex = 1
    end,

    intro = function (self)
        ui:openPopup( '开始', Chapters[self.currentMapIndex].intro, Chapters[self.currentMapIndex].introBtn, function() end )
    end,

    lose = function (self)
        ui:openPopup( '失败', Chapters[self.currentMapIndex].lose, Chapters[self.currentMapIndex].loseBtn,function() exit() end )
    end,

    win = function(self)
        ui:openPopup( '过关', Chapters[self.currentMapIndex].clear, Chapters[self.currentMapIndex].clearBtn,function() 
            if self.currentMapIndex == #Chapters then
                exit() 
            else 
                self.curUnitList = {}
                self.curStaticUnitList = {}
                self.currentMapIndex = self.currentMapIndex + 1
                self:loadStage()
            end
        end )
    end,

    reloadStage = function(self)
        self.curStaticUnitList = {}
        self.curUnitList = {}
        self:loadStage()
    end,

    loadStage = function(self)
        local mapData = nil
        if DEBUG_USE_TEST_LEVEL == false then
            mapData = mapGenerator:loadMapStructure( mapGenerator:generateMap( true ) )
            Chapters[self.currentMapIndex].mapData = mapData
        else
            mapData = Chapters[self.currentMapIndex].mapData
        end

        -- re-initialize the game board
        self.board = {}
        for i = 1, MapTile_WH do
            local newCol = {}
            table.insert( self.board, newCol )
            for j = 1, MapTile_WH do
                local newRow = {}
                table.insert( newCol, newRow )
            end
        end

        self:generateUnitByMapData( mapData, MapTile_WH-1, MapTile_WH-1 )
        self:sortByLevel()
    end,

    sortByLevel = function(self)
        local sortByLayer = function(a, b)
            return a.cfg.layer < b.cfg.layer
        end
        print( '--------------------- before sort ---------------------' )
        if DEBUG_RENDER_ORDER then for k,v in ipairs( self.curUnitList ) do v:info( '#render#' ) end end
        self.curUnitList = sort( self.curUnitList, sortByLayer )
        print( '--------------------- after sort ---------------------' )
        if DEBUG_RENDER_ORDER then for k,v in ipairs( self.curUnitList ) do v:info( '#render#' ) end end
    end,

    generateUnitByMapData = function( self, mapData, w, h)
        local createConfigDefault = { id = -1, x = -1, y = -1, count = 1, level = 1, unitDef = nil, sealId = -1, special = false }
        local expectedLevelList = {1,1,1,1,1,1,1,2,2,2,2,2,3,3,3,3,4,4,5,1,1,1,1,1,1,1,2,2,2,2,2,3,3,3,3,4,4,5,1,1,1,1,1,1,1,2,2,2,2,2,3,3,3,3,4,4,5,1,1,1,1,1,1,1,2,2,2,2,2,3,3,3,3,4,4,5,1,1,1,1,1,1,1,2,2,2,2,2,3,3,3,3,4,4,5}
        local createList = {}
        
        -- collect all the units / terrains that need to be generated
        for i = 0, w do
            for j = 0, h do
                local id = mget(mapData, i, j)
                local sealUnitKey, multi = UnitFactory_GetUnitKeyAndCountFromSeal( id, self.currentMapIndex, 1 )
                if sealUnitKey == nil then
                    local def = UnitFactory_GetUnitFullDefById(id)
                    if def ~= nil then
                        -- if it's a normal unit or terrain
                        if DEBUG_UNIT_GENERATE then print('UNITCOMM', '', id, i, j) end
                        table.insert( createList, merge( copy( createConfigDefault ), 
                            { id = id, x = i, y = j, unitDef = def } ) )
                    else
                        if DEBUG_UNIT_GENERATE then warn('UNITSKIP', '', id, i, j) end
                        table.insert( createList, merge( copy( createConfigDefault ), 
                            { id = id, x = i, y = j, special = true } ) )
                    end
                else
                    if DEBUG_UNIT_GENERATE then print('UNITSEAL', '', UnitDef[sealUnitKey].id, i, j, multi, id) end
                    for ii = 1, multi do
                        -- if it's a seal
                        table.insert( createList, merge( copy( createConfigDefault ), 
                            { id = UnitDef[sealUnitKey].id, x = i, y = j, count = 1, sealId = id, unitDef = UnitFactory_GetUnitFullDefById(UnitDef[sealUnitKey].id) } ) )
                    end
                end
            end
        end

        -- assign all levels
        createList = shuffle( createList )
        levelAssigning = #expectedLevelList
        levelAssigningCount = {}
        for k, v in ipairs( createList ) do
            if DEBUG_UNIT_GENERATE then print('UNITSHUF', '', v.id, v.x, v.y, v.count, v.sealId, v.unitDef) end
            if v.unitDef ~= nil and v.unitDef.level ~= nil and #v.unitDef.level > 0 then
                v.level = expectedLevelList[levelAssigning]
                levelAssigning = levelAssigning - 1
                if levelAssigning == 0 then
                    levelAssigning = 1
                end
                table.insert( levelAssigningCount, v.level )
            end
        end
        if levelAssigning > 1 then
            warn( 'Level assigning not complete '..#levelAssigningCount..'/'..#expectedLevelList )
            printArray( 'Assigned levels: ', levelAssigningCount )
        else
            print( 'Level assigning finished '..#levelAssigningCount..'/'..#expectedLevelList )
            printArray( 'Assigned levels: ', levelAssigningCount )
        end

        for k, v in ipairs( createList ) do
            UnitFactory_CreateUnit( v.id, v.x, v.y, v.count, v.level, nil )
        end
    end,

    setup = function ( self )
        
        self.hint = Resources.load('spr/star.spr')
        self.hint:play('idle', true, true)
        self.whitestar = Resources.load('spr/whitestar.spr')
        self.whitestar:play('idle', true, true)
        self.blind = Resources.load('spr/blind.spr')
        self.blind:play('idle', true, true)

        if DEBUG_UI_LAYOUT then
            UnitFactory_CreateUnit( PLAYER.id, 0, 0, 1, 1)
            UnitFactory_CreateUnit( GOAL.id, MapTile_WH-1, MapTile_WH-1, 1, 1)
        else
            if DEBUG_ANALYSIS_LEVEL == true then
                Chapters = {}
            end
    
            if DEBUG_USE_TEST_LEVEL then
                table.insert( Chapters, 1, {
                    intro = { '测试', '测试', '（合成点什么来保护你自己吧）' },
                    introBtn = '开始',
                    clear = {'测试', '测试', '测试...'},
                    clearBtn = '继续',
                    lose = {'测试', '测试', '（合成升级武器和护盾会让游戏更容易)'},
                    loseBtn = '结束',
                    mapData = Resources.load( TEST_MAP ),
                })
            elseif DEBUG_ANALYSIS_LEVEL then
                table.insert( Chapters, 1, {
                    intro = { '单位分析', '单位分析', '（...）' },
                    introBtn = '开始',
                    clear = {'单位分析', '单位分析', '单位分析...'},
                    clearBtn = '继续',
                    lose = {'单位分析', '单位分析', '（...)'},
                    loseBtn = '结束',
                    mapData = Resources.load( 'level/analysis_allunits.map' ),
                })
            end
    
            self:loadStage()
        end

        if DEBUG_WEAPON then
            for k,v in ipairs( EquipmentDefList ) do
                Equipment_info( 'EquipDef ', v )
            end
        end

        if DEBUG then
            self.currency.crystal1 = 50
            if self.player ~= nil then self.weapon.cfg.sight = 42 end
            game:upgradeEquipment( FindEquipmentById('弓箭1'), true )
            game:unlockEquipment( '剑1' )
            game:unlockEquipment( '冲刺矛1' )
            game:unlockEquipment( '劈山斧1' )
            game:upgradeEquipment( FindEquipmentById('护盾3'), true  )
            game.player:changeState()
        else
            self.currency.crystal1 = 0
            game:upgradeEquipment( FindEquipmentById('弓箭1'), true )
            game:unlockEquipment( '剑1' )
            game:unlockEquipment( '冲刺矛1' )
            game:unlockEquipment( '劈山斧1' )
            game:upgradeEquipment( FindEquipmentById('护盾1'), true  )
            game.player:changeState()
        end
		if DEBUG_MORE_CRYSTAL then
            self.currency.crystal1 = 50
            self.currency.crystal2 = 30
            self.currency.crystal3 = 20
            self.currency.crystal4 = 10
            game.player:changeState()
		end
        if DEBUG_USE_TEST_LEVEL then
            game.weapon.cfg.sight = 42
        end
    end,

    gameLoop = function(self, delta)
        -- update unit animations and check whether all their turn has finished
        local turnFinished = true
        local hasNextAction = false
		if self.player ~= nil then
	        self.player:update( delta )
	        turnFinished = turnFinished and self.player:getTurnFinished()
		end
        for k, v in ipairs(self.curUnitList) do
            local xx, yy = v:getLogicPos()
            if self:isPlayerInRange( xx, yy, self.disableRange ) then
                v:update( delta )
                turnFinished = turnFinished and v:getTurnFinished()
            end
        end
        if not( turnFinished ) or not( tweenManager:getAllFinished() ) then
            -- if one of the unit hasn't finished, then let them let them keep going
        else
			if self.player ~= nil then
	            -- otherwise, try start a player action first
	            hasNextAction = self.player:nextAction()
	            if not ( hasNextAction ) then
	                -- if the player has no action to perform, then all other units will stand by wait for the player
	            else
                    if DEBUG_RENDER_ORDER then for k,v in ipairs( game.curUnitList ) do v:info( '#render#' ) end end
                    print( '--------------------- turn ' .. self.turn .. ' ---------------------' )
                    self.turn = self.turn + 1
	                -- otherwise, if the player moved, all other units will try to act, if they have any intent to do so
	                for k,v in ipairs( self.curUnitList ) do
	                    if v.nextAction ~= nil then
                            local xx, yy = v:getLogicPos()
                            if self:isPlayerInRange( xx, yy, self.disableRange ) then
                                v:nextAction()
                            end
	                    end
	                end
	            end
			end
        end
    end,

    update = function (self, delta)

        if DEBUG_KEYS then
            --[[
                R： 重新生成本关卡
                I：上一关卡
                O：下一关卡
                E： 装备至该关卡标准
            ]]
            if keyp(KeyCode.R) then
                print('', '重新生成地图，等级'..self.currentMapIndex)
                self:reloadStage()
            end
            if keyp(KeyCode.O) then
                self.currentMapIndex = self.currentMapIndex + 1
                if self.currentMapIndex > #Chapters then
                    self.currentMapIndex = #Chapters
                end
                print('', '切换地图等级，等级'..self.currentMapIndex)
            end
            if keyp(KeyCode.I) then
                self.currentMapIndex = self.currentMapIndex - 1
                if self.currentMapIndex < 1 then
                    self.currentMapIndex = 1
                end
                print('', '切换地图等级，等级'..self.currentMapIndex)
            end
            if keyp(KeyCode.E) then
                local weapon, shield = Analysis_Level_Equipments( self.currentMapIndex )
                self:upgradeEquipment( FindEquipmentById(weapon), true )
                self:upgradeEquipment( FindEquipmentById(shield), true )
                game.player:changeState()
                print('', '切换玩家装备到预期，等级'..self.currentMapIndex)
            end
            if keyp(KeyCode.D) then
                -- firing a dropping crystal
                local xx, yy = mouse(1)
                Projectile_DropCrystals( xx, yy, { crystal1 = 10 } )
            end
            if keyp(KeyCode.P) then
                ui:openPopup( 'popuptest', {'popuptest', 'popuptest', 'popuptest'}, 'test', function() print('popup onConfirm') end )
            end
            if keyp(KeyCode.Num1) then
                -- firing a dropping crystal
                local xx, yy = mouse(1)
                Projectile_DropCrystals( xx, yy, { crystal1 = 10 } )
            end
            if keyp(KeyCode.Num2) then
                -- firing a dropping crystal
                local xx, yy = mouse(1)
                Projectile_DropCrystals( xx, yy, { crystal2 = 10 } )
            end
            if keyp(KeyCode.Num3) then
                -- firing a dropping crystal
                local xx, yy = mouse(1)
                Projectile_DropCrystals( xx, yy, { crystal3 = 10 } )
            end
            if keyp(KeyCode.Num4) then
                -- firing a dropping crystal
                local xx, yy = mouse(1)
                Projectile_DropCrystals( xx, yy, { crystal4 = 10 } )
            end
            local cameraSpeed = 250
            if key(KeyCode.G) then
                mainCamera:moveCameraPos( 0, 1 * delta * cameraSpeed )
            end
            if key(KeyCode.T) then
                mainCamera:moveCameraPos( 0, -1 * delta * cameraSpeed )
            end
            if key(KeyCode.H) then
                mainCamera:moveCameraPos( 1 * delta * cameraSpeed, 0 )
            end
            if key(KeyCode.F) then
                mainCamera:moveCameraPos( -1 * delta * cameraSpeed, 0 )
            end
            if keyp(KeyCode.M) then
                self.currency.crystal1 = self.currency.crystal1 + 50
                self.currency.crystal2 = self.currency.crystal2 + 30
                self.currency.crystal3 = self.currency.crystal3 + 20
                self.currency.crystal4 = self.currency.crystal4 + 10
                game.player:changeState()
            end
        end

        tweenManager:update(delta)

        self:gameLoop(delta)

        local newlySeenGrid = {}
        

        local doRenderLogic = function( list, isUpdate )
            for k, v in ipairs(list) do
                local vx, vy = v:getLogicPos()
                if self:isInCamera( v ) then
                    if self.player ~= nil then
                        if isUpdate then
                            v:update(delta)
                        end
                        if self.player:isInSight( vx, vy ) then
                            local id = ''..vx..' '..vy
                            if v.cfg.seen == false and not exists( newlySeenGrid, id ) and v.cfg.is_terrain then
                                table.insert( newlySeenGrid, id )
                            end
                            v.cfg.seen = true
                            v:render( delta )
                        elseif v.cfg.is_terrain and v.cfg.seen then
                            v:render( delta )
                            spr( self.blind, vx * 32 + ui.mox, vy * 32 + ui.moy, 32, 32)
                        elseif v.cfg.is_terrain then
                            spr( self.whitestar, vx * 32 + ui.mox, vy * 32 + ui.moy, 32, 32)
                        end
                    else 
                        if isUpdate then
                            v:update(delta)
                        end
                        v:render(delta)
                    end
                end
            end
        end

        -- render logic
        doRenderLogic( self.curStaticUnitList, false )
        doRenderLogic( self.curUnitList, true )

		if self.player ~= nil then
        	self.player:render( delta )
            local px, py = self.player:getRenderPos()
            self.weapon:render( px, py, 32 * 0.5, 32 * 0.5, 0.5, math.pi * 0)
		end

        if game.shield.cfg.energy_power < game.shield.cfg.energy_power_max then
            for k, v in ipairs( newlySeenGrid ) do
                local pos = mysplit( v )
                local posX, posY = ui.mox + 32 * pos[1] + math.random(0, 16), ui.moy + 32 * pos[2] + math.random(0, 16)
                local amount = math.ceil( game.shield.cfg.energy_power_max / 10 )
                Projectile_DropShield( posX, posY, 1, amount )
            end
        end

        tweenManager:render()

        for k, v in ipairs(self.curEffectList) do
            v:render( delta )
        end

        if DEBUG_LEVEL and Chapters[self.currentMapIndex].mapData ~= nil then
            map( Chapters[self.currentMapIndex].mapData, 0, ui.moy + 40 )
        end

        if self.uiDirty then
            ui:updateCraftPanel(false)
            self.uiDirty = false
        end
    end,

    upgradeEquipment = function ( self, equipDef, isFree )
        print('打造 ' .. equipDef.desc) 
        isFree = isFree == true or false
        local n = Equipment.new( equipDef )
        local lastEquipment = ''
        if isFree == false then
            if not( Equipment_canAfford( n.cfg ) ) then return end
            Equipment_cost( equipDef )
        end
        self:unlockEquipment( n.cfg.id )
        if equipDef.etype == 'weapon' then
            self.weapon:info( 'upgradeEquipment:Old' )
            lastEquipment = self.weapon.cfg
            local used = self.weapon.cfg.energy_max - self.weapon.cfg.energy
            self.weapon = n
            self.weapon.cfg.energy = self.weapon.cfg.energy_max - used
			-- below code can fix ui problem and create game hacks
			-- if self.weapon.cfg.energy < 0 then self.weapon.cfg.energy = 0 end
            self.weapon:info( 'upgradeEquipment:NewAdjusted' )
        else
            self.shield:info( 'upgradeEquipment:Old' )
            lastEquipment = self.shield.cfg
            local used = self.shield.cfg.energy_power_max - self.shield.cfg.energy_power
            self.shield = n
            self.shield.cfg.energy_power = self.shield.cfg.energy_power_max - used
            self.shield:info( 'upgradeEquipment:NewAdjusted' )
        end
    end,

    unlockEquipment = function( self, id )
        if not exists( self.craftedEquipments, id ) then
            table.insert( self.craftedEquipments, id )
        end
    end,

    filterEquipmentByCrafted = function( self )
        return FilterEquipmentByCrafted( self.craftedEquipments )
    end,

    searchAdjustMap = function ( self, m, id, x, y )
        local r = {}
        for i = 1, 8 do
            local xx = x + adjust8X[i]
            local yy = y + adjust8Y[i]
            local vv = mget(m, xx, yy)
            if id == vv then
                table.insert( r, { x = xx, y = yy } )
            end
        end
        return r
    end,

    getEmptySpaceInRange = function ( self, x, y, rangemin, rangemax )
        local result = {}
        for i = -rangemax,rangemax do
            for j = -rangemax,rangemax do
                if (x+i)*(x+i) + (y+j)*(y+j) <= rangemin * rangemin then
				else 
	                if self:getBlocked( x + i, y + j ) == nil and self:isPlayer( x + i, y + j ) == false then
	                    table.insert( result, {x = x+i, y = y+j } )
	                end
				end
            end
        end
        return result
    end,
        
    getBlocked = function ( self, x, y )
        for k, v in ipairs(game:getBoard(x, y)) do
            if v.isShow == true and v.cfg.blocking == true then
                return v
            end
        end
        return nil
    end,

    getFirstBlocked = function( self, x, y, lst )
        for kk,vv in ipairs( lst ) do
            local blockedBy = self:getBlocked( x + vv.x, y + vv.y )
            if blockedBy ~= nil then 
				return blockedBy, vv.x, vv.y
			end
        end
        return nil, x, y
    end,

    convertPosToFacingDirection = function( self, facingDirection, posInUpDirection )
        local upDir = { x = 0, y = 1 }
        if facingDirection.x == 1 and facingDirection.y == 0 then
            return { x = posInUpDirection.y, y = -posInUpDirection.x }
		end
        if facingDirection.x == 0 and facingDirection.y == -1 then
            return { x = -posInUpDirection.x, y = -posInUpDirection.y }
		end
        if facingDirection.x == -1 and facingDirection.y == 0 then
            return { x = -posInUpDirection.y, y = posInUpDirection.x }
		end
        if facingDirection.x == 0 and facingDirection.y == 1 then
            return { x = posInUpDirection.x, y = posInUpDirection.y }
		end
        return { x = 0, y = 0 }
    end,

    searchPlayer = function ( self, lst, x, y )
        local a = filter( lst, function(l) return self:isPlayer( l.x + x, l.y + y ) end )
        if #a > 0 then 
            return a[1] 
        else 
            return nil 
        end
    end,

    getUnitAtPos = function( self, x, y )
        return self:getBoard(x, y)
    end,

    getUnitsInRange = function(self, x, y, range )
        local rlt = {}
        for i = x - range, x + range do
            for j= y - range, y + range do
                for k, v in ipairs(game:getBoard(i, j)) do
                    local vx, vy = v:getLogicPos()
                    if (vx-x)*(vx-x)+(vy-y)*(vy-y) <= range * range then
                        table.insert( rlt, v )
                    end
                end
            end
        end
        return rlt
    end,

    isPlayerInRange = function(self, x, y, range )
        local vx, vy = self.player:getLogicPos()
        return (vx-x)*(vx-x)+(vy-y)*(vy-y) <= range * range
    end,

    isInCamera = function(self, v)
        local rx, ry = v:getRealPos()
        local cx, cy = mainCamera:getCameraPos()
        return rx >= cx - 32 and rx <= cx + 960 + 32 and ry >= cy - 32 and ry <= cy + 640 + 32
    end,
    
    isPlayer = function ( self, x, y )
        local px, py = self.player:getLogicPos()
        return px == x and py == y
    end,
        
    removeUnit = function ( self, vv )
        if vv.cfg.is_static then
            for k = #self.curStaticUnitList, 1, -1 do
                local v = self.curStaticUnitList[k]
                if vv == v then
                    table.remove( self.curStaticUnitList, k )
                end
            end
        else
            for k = #self.curUnitList, 1, -1 do
                local v = self.curUnitList[k]
                if vv == v then
                    table.remove( self.curUnitList, k )
                end
            end
        end
        self:removeFromBoardByXY( vv )
    end,

    addUnit = function( self, u )
        if u.cfg.is_static then
            table.insert( self.curStaticUnitList, u )
        else
            table.insert( self.curUnitList, u )
        end
		if u.cfg.is_boss == false then
	        self:addToBoardByXY(u)
		end
    end,

    removeFromBoardByXY = function( self, u )
        local x,y = u:getLogicPos()
        if x < 0 or x > MapTile_WH or y < 0 or y > MapTile_WH then error( 'board position not found '..'x'..x..' y'..y..' ' .. Debug.trace() ) end
        remove( self:getBoard(x, y), u )
    end,

    addToBoardByXY = function( self, u )
        local x,y = u:getLogicPos()
        if x < 0 or x > MapTile_WH or y < 0 or y > MapTile_WH then error( 'board position not found '..'x'..x..' y'..y..' ' .. Debug.trace() ) end
        table.insert( self:getBoard(x, y), u )
    end,

    existsOnBoardByXY = function( self, u )
        if self.board == nil or #self.board == 0 then return false end
        local x,y = u:getLogicPos()
        return exists( self:getBoard(x, y), u )
    end,

    getBoard = function( self, x, y )
        local xx, yy = x+1, y+1
        if xx < 1 or xx > MapTile_WH or yy < 1 or yy > MapTile_WH then 
			return {} 
		end
		if self.board == nil or self.board[xx] == nil or self.board[xx][yy] == nil then
            return self:getBoard( math.floor( x ), math.floor( y ) )
		end
        return self.board[xx][yy]
    end,
    
    chargeWeapon = function (self)
        local dx = self.weapon.cfg.energy_max - self.weapon.cfg.energy
        local primary = Crystals_getPrimary( self.weapon.cfg.recharge_cost )
        
        if self.currency[primary] < dx then
            dx = self.currency[primary]
        end
        self.weapon.cfg.energy = self.weapon.cfg.energy + dx
        self.currency[primary] = self.currency[primary] - dx
        self.player:changeState()
    end,
    
    createEffect = function ( self, img, state, x, y, dx, dy, wM, hM, callback )
        local e = nil
        local removeEffect = function ()
            table.remove( self.curEffectList, tablefind( self.curEffectList, e ) )
            if callback ~= nil then
                callback()
            end
        end
        if state ~= '' then
            e = EffectAtt.new( img, state, x, y, dx, dy, wM, hM, removeEffect )
        else
            e = EffectFolder.new( img, x, y, dx, dy, wM, hM, removeEffect )
        end
        table.insert( self.curEffectList, e )
    end,

    curAtt = function (self, blocker)
        local att_total = -1
        if blocker.cfg.is_terrain then
            att_total = self.weapon.cfg.att_terrain
        elseif self.weapon.cfg.energy > 0 then
            att_total = self.weapon.cfg.att
        else
            att_total = self.weapon.cfg.min_att
        end
        return att_total
    end,
})

game = Game.new()