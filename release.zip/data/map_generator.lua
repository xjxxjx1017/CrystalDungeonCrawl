require 'code/class'
require 'code/co'
require 'code/util'

MapTile_WH = 32

MapModule = class({
    countH = 0,
    countW = 0,
    data = {},
    key = 0,

    ctor = function( self, data, key )
        self.data = data
        self.countW = #data
        self.countH = #data[1]
        self.key = key
    end
})


MapGenerator = class({
    mapH = MapTile_WH,
	mapW = MapTile_WH, 
    module_8xN = nil,
    module_NxN = nil,
    module_boss = nil,
    module_player = nil,
    debug_module = nil,

    ctor = function( self )
    end,

    setup = function( self )
        self:loadDesigns()
    end,

    loadDesigns = function( self )
        -- 加载地图文件
        self.module_8xN = self:loadSource( Resources.load( 'level_modules/module_8xN2.map' ) )
        self.module_NxN = self:loadSource( Resources.load( 'level_modules/module_NxN.map' ) )
        self.module_boss = self:loadSource( Resources.load( 'level_modules/module_boss.map' ) )
        self.module_player = self:loadSource( Resources.load( 'level_modules/module_player.map' ) )
    end,

    loadMapStructure = function( self, module )
        local data = {
            tiles = {
                count = { MapTile_WH, MapTile_WH }
            },
            width = self.mapW, 
			height = self.mapH,
            data = module,
            ref = 'bank.png'
        }
        self:printModule( data )
        local m = Resources.load(data, Map)
        self:printMap(m)
        return m
    end,

    printDebugModule = function(self)
        if self.debug_module ~= nil and DEBUG then
            map( self.debug_module, 0, 0 )
        end
    end,

    printMap = function( self, data )
        for i = 0, MapTile_WH do
            local line = ''
            for j = 0, MapTile_WH do
                local c = mget(data, i, j)
                line = line .. " " .. c
            end
            print( line )
        end
    end,

    printModule = function( self, data )
        for i = 1, MapTile_WH do
            local line = ''
            for j = 1, MapTile_WH do
                line = line .. " " .. data.data[(i-1) * MapTile_WH + j]
            end
            print( line )
        end
    end,

    findModule = function( self, source, w, h, used )
        local sRand = shuffle( source )
        for k,v in ipairs( sRand ) do
            if (w == nil or v.countW == w) and (h == nil or v.countH == h) then
				if (used == nil or not( exists( used, v.key ) )) then
	                print( '', 'found module', w, h, v.key )
	                return v.key, source[v.key]
				end
            end
        end
        print( '', 'not found module' )
        return nil
    end,

    generateMap = function( self, hasBoss )
        --[[
        - 生成类似关卡的步骤:
          1. 中线划分，左右，或者上下。分成两块8x16的区域
          2. 把每一区域，再从长的一边切为长4~7大小的区域。如果出现1或2大小无法分割，则在任意位置Fill
          3. 若这关有BOSS，则用BOSS房间覆盖一个角落。
          4. 玩家则生成在BOSS的对角角落，或附近的边沿。清空玩家附近1格内的怪。
          5. 接着从模板里选择大小跟区域大小相同的设计，并应用。边角处的区域需要边角处的模块设计。
          6. 若没找到设计，则先寻找更小一些的设计。
          7. 若没找到，则生成考虑平衡性的的随机地形。
          8. 生成地图后计算路径，先确定玩家可以到达所有区域。如果不行，则报错。（在这个阶段还不能通过的模块。之后也许可以通过设计处理，比如可以挖墙，增加不同区域的奖励。当然也可以通过程序处理）
        ]]

        local mapData16x16 = {}
        local possibleDivides = { {8, 8} }
        -- local possibleDivides = { {7,5,4}, {7,5,4}, {6,5,5}, {6,6,4}, {7,5,4}, {6,5,5}, {6,6,4} }
        local twoSide = {} -- choose two possible divide combination
        local usedMaps = {}

        -- 建立空的区域
        table.insert( twoSide, shuffle( possibleDivides[math.random(1,#possibleDivides)] ) )
        table.insert( twoSide, shuffle( possibleDivides[math.random(1,#possibleDivides)] ) )
        -- TODO: 标注边角


        -- check how many maps to create
        local genCount = MapTile_WH / 16
        local genMap = {}
        for iii = 1, genCount do
            for jjj = 1, genCount do
                table.insert( genMap, {} )
            end
        end

        for iii = 1, genCount do
            for jjj = 1, genCount do
                local d = {}
                
                for s = 1,2 do
                    local side = twoSide[s]
                    local w = 8
                    local m = nil
                    for h1, h in ipairs( side ) do
                        local mid = self:findModule( self.module_8xN, h, w, usedMaps )
                        -- 避免使用已使用的设计
                        if mid ~= nil then
                            table.insert( usedMaps, mid )
                        else
                            -- TODO: 若没找到设计，则Fill整个地图为森林，草，河流，或山。
                            mid = self:findModule( self.module_8xN, h, w, {} )
                        end
                        
                        m = self.module_8xN[mid]
                        -- 随机上下左右翻转设计，应用设计到区域
                        local xx = { { 1, 1 * h, 1 }, { 1 * h, 1, -1 } }
                        local yy = { { 1, 1 * w, 1 }, { 1 * w, 1, -1 } }
                        local xDir = xx[math.random(1,2)]
                        local yDir = yy[math.random(1,2)]
                        print( '', 'applying design', xDir[1], xDir[2], #m.data, '#', yDir[1], yDir[2], #m.data[1] )
                        for i = xDir[1], xDir[2], xDir[3] do
                            local column = {}
                            for j = yDir[1], yDir[2], yDir[3] do
                                v = m.data[i][j]
                                table.insert( column, v )
                            end
                            table.insert( d, column )
                        end
                    end
                end
                
                local d2 = {}
                for i = 1, 16 do
                    local column = {}
                    for j = 1,8 do
                        table.insert( column, d[i][j] )
                    end
                    for j = 1,8 do
                        table.insert( column, d[i + 16][j] )
                    end
                    table.insert( d2, column )
                end
                if math.random() > 0.5 then
                    -- 随机地做90度的rotate
                    d2 = RotateMatrix( d2, 16 )
                end
                genMap[iii][jjj] = d2
            end
        end

        local genMap2 = {}
        for iii = 1, genCount do
            for ii = 1, 16 do
                local column = {}
                for jjj = 1, genCount do
                    column = concat( column, genMap[iii][jjj][ii] )
                end
                table.insert( genMap2, column )
            end
        end

        local playerBossPos = math.random(1,2)
        -- overlay，BOSS位置
        -- 任何一关都有25%的几率出现boss的巢穴。
        local b, bossM = self:findModule( self.module_boss )
        local bossWs = {MapTile_WH - bossM.countW, 0} -- 7 - math.floor(bossM.countW / 2)
        local bossW = bossWs[ playerBossPos ]
        for i = 1, bossM.countW do
            for j = 1, bossM.countH do
                genMap2[j][i + bossW] = bossM.data[i][j]
            end
        end

        -- overlay，玩家位置
        local b, playerM = self:findModule( self.module_player )
        local playerWs = {0, MapTile_WH - playerM.countW} -- 7 - math.floor(playerM.countW / 2)
        local playerW = playerWs[ playerBossPos ]
        local playerH = MapTile_WH - playerM.countH
        for i = 1, playerM.countW do
            for j = 1, playerM.countH do
                genMap2[j + playerH][i + playerW] = playerM.data[i][1 + playerM.countH - j]
            end
        end

        local d3 = {}
        for i = 1, MapTile_WH do
            for j = 1,MapTile_WH do
                table.insert( d3, genMap2[i][j] )
            end
        end

        -- 重复多次，生成多张地图。

        return d3
    end,

    loadSource = function( self, source )
        -- 遍历地图文件，提取设计，并建立区域模块。
        local END_MARK = 37
        local maps = {}
        local curMapData = nil
        for i = 1, 999 do
            if curMapData == nil then
                curMapData = {}
            end
            local col = {}
            for j = 1, self.mapH do
                local t = mget( source, i - 1, j - 1 )
                if t ~= END_MARK and t >= 0 then
                    table.insert( col, t )
                else
                    -- if it's an end mark, then stop there
                    break
                end
            end
            if #col > 0 then
                -- if the column contains any valid tile, then add it to the current map data
                table.insert( curMapData, col )
            else
                -- if the column start with a END mark, then 
                -- try save the map if there's any columns in there
                if #curMapData > 0 and #curMapData <= self.mapW then
                    table.insert( maps, MapModule.new( curMapData, #maps + 1 ) )
                end
                -- start a new map
                curMapData = nil
            end
        end
        return maps
    end,
})

mapGenerator = MapGenerator.new({})