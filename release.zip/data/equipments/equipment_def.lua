
require 'code/class'

TANDAO_LIMIT_1 = 0.5
TANDAO_LIMIT_2 = 0.2

CRYSTALS = { crystal1 = 0, crystal2 = 0, crystal3 = 0, crystal4 = 0, crystal_main = 0 }

Crystals_multiply = function( crystal, multi )
    local result = {}
	local crystal = merge( copy(CRYSTALS), crystal )
    for k,v in pairs( CRYSTALS ) do
		if crystal[k] == nil or multi == nil then
			a = 0
			end
        result[k] = crystal[k] * multi
    end
    return result
end

Crystals_canAfford = function ( cost )
	local crystal = merge( copy(CRYSTALS), cost )
    if crystal.crystal_main > 0 then
        return Crystals_canAfford( Crystals_primaryFromAny( cost ) )
    end
    for k,v in pairs(CRYSTALS) do
        if cost[k] ~= nil and cost[k]  > game.currency[k] then return false end
    end
    return true
end

Crystals_primaryFromAny = function( cost )
    if cost.crystal_main <= 0 then return cost end
	local crystal = merge( copy(CRYSTALS), cost )
    local k = Crystals_getPrimary( game.weapon.cfg.cost )
    local amount = crystal.crystal_main
    local ck = {}
    ck[k] = amount
    return ck
end

Crystals_sum = function ( cost )
	local crystal = merge( copy(CRYSTALS), cost )
    local sum = 0
    for k,v in pairs(CRYSTALS) do
        if cost[k] ~= nil then 
            sum = sum + cost[k]
        end
    end
    return sum
end

Crystals_getPrimary = function ( cost )
	local crystal = merge( copy(CRYSTALS), cost )
    if crystal.crystal_main > 0 then
        return Crystals_getPrimary( game.weapon.cfg.cost )
    end
    for k,v in pairs(CRYSTALS) do
        if cost[k] ~= nil and cost[k]  > 0 then return k end
    end
    return 'crystal1'
end

Equipment_GetCrystalColor = function( cost )
    local full_cost = merge( copy(CRYSTALS), cost )
    if full_cost.crystal_main > 0 then
        full_cost[ Crystals_getPrimary( game.weapon.cfg.cost ) ] = 100
    end
    if full_cost.crystal4  > 0 then
        return Color.new( 255, 0, 0, 255 )
    elseif full_cost.crystal3  > 0 then
        return Color.new( 241, 227, 0, 255 )
    elseif full_cost.crystal2  > 0 then
        return Color.new( 69, 228, 171, 255 )
    elseif full_cost.crystal1  > 0 then
        return Color.new( 0, 167, 181, 255 )
    end
end

EquipmentDefault = {
    -- 费用属性
    cost = copy( CRYSTALS ),
    -- 通用属性
    id = '没', img = 'spr_weapon/question.spr', desc = '没', btn = '没', descDetails='没描述', level_up = {},
    -- 武器属性
    att = 0, min_att = 0, att_terrain = 0, att_self_stun = 0, is_aoe = false, energy_max = 0, energy = 0, recharge_cost = copy( CRYSTALS ), range = { { x = 0, y = 1 } }, range_weak = {},
	sight = 2.5,
    -- 防具属性
    energy_power = 0, energy_power_max = 0, charge_buff = nil, ai = nil,
    -- force move属性
    force_move = 0, force_move_max = 0, cur_force_move = nil, force_att = 0, force_att_max = 0
}

EquipmentDefList = {}

EQUIPMENT_DEFAULT = { 
    id = '无', desc = '装备：无', cost = {}, att = 0, att_terrain = 1, energy_max = 0, energy = 0, min_att = 0, energy_power = 0, energy_power_max = 0, level_up = {}
}

-- 普通的护盾-等级1
EQUIPMENT_SHIELD1 = { 
    id = '护盾1', img = 'spr_weapon/shield.spr', category = '护盾', etype = 'shield', desc = '护盾1', cost = { crystal_main = 5 }, btn = '打造', energy_power = 20, energy_power_max = 20,
    descDetails='< 小秘密 >\n就算护盾为1，它也能完全抵挡一次攻击。', 
    level_up =  {'护盾2'}, keyReceipt = true
} 
table.insert( EquipmentDefList, EQUIPMENT_SHIELD1 )

-- 护盾系列
for i = 2, 20, 1 do
    local equipDef = merge( copy( EQUIPMENT_SHIELD1 ), {
        id = '护盾'..i, img = 'spr_weapon/shield.spr', desc = '护盾'..i, cost = { crystal_main = math.floor(5 * 1.4^i) }, btn = '增强', energy_power = 15 + math.floor(5 * i * (1.1^i) ), energy_power_max = 15 + math.floor(5 * i * (1.1^i) ), level_up = { '护盾'..(i+1) },
        descDetails='< 小秘密 >\n就算护盾为1，它也能完全抵挡一次攻击。'
    })
    if i == 20 then equipDef.level_up = {} end
    table.insert( EquipmentDefList, equipDef )
end

-- 普通的剑-等级1
EQUIPMENT_SWORD1 = { 
    id = '剑1', img = 'spr_weapon/swordbase.spr', category = '剑', etype = 'weapon', desc = '剑1', cost = { crystal1 = 5 }, btn = '打造', att = 2, min_att = 1, att_terrain = 1, energy_max = 10, energy = 10, recharge_cost = { crystal1 = 1 }, range = { { x = 0, y = 1 } }, 
    descDetails='< 狂暴 >\n主动攻击之后，会接着进行两次攻击', 
    level_up =  { '剑2' }, level = 1, force_att_max = 2
}
table.insert( EquipmentDefList, EQUIPMENT_SWORD1 )

-- 普通的剑-等级2
EQUIPMENT_SWORD2 = merge( copy(EQUIPMENT_SWORD1), {
    -- 一次升级(蓝水晶8，att+1，充能3，充能花费4)
    id = '剑2', img = 'spr_weapon/swordbase.spr', desc = '剑2', 
    descDetails='< 狂暴 >\n主动攻击之后，会接着进行两次攻击', cost = { crystal1 = 8 }, btn = '升级', att = 3, energy_max = 15, recharge_cost = { crystal1 = 1 }, level_up = { '剑3', '二段剑1', '彩虹剑1' }, level = 2, force_att_max = 2
})
table.insert( EquipmentDefList, EQUIPMENT_SWORD2 )

-- 普通的剑-等级3
EQUIPMENT_SWORD3 = merge( copy(EQUIPMENT_SWORD1), {
    -- 一次升级(蓝水晶8，att+1，充能3，充能花费4)
    id = '剑3', img = 'spr_weapon/swordbase.spr', desc = '剑3', 
    descDetails='< 狂暴 >\n主动攻击之后，会接着进行两次攻击', cost = { crystal1 = 8 }, btn = '升级', att = 4, energy_max = 20, recharge_cost = { crystal1 = 1 }, level_up = { '斩剑1', '硬铁剑1' }, level = 3, force_att_max = 2
})
table.insert( EquipmentDefList, EQUIPMENT_SWORD3 )

-- 硬铁剑系列
for i = 1, 10, 1 do
    local swordDef = merge( copy(EQUIPMENT_SWORD1), {
        id = '硬铁剑'..i, img = 'spr_weapon/sword_yingtie.spr', category = '硬铁剑', 
        descDetails='< 狂暴 >\n主动攻击之后，会接着进行两次攻击', desc = '硬铁剑'..i, cost = { crystal1 = math.floor(5 * 1.2^i) }, btn = '升级', att = 4 + i, energy_max = 25 + i * 5, recharge_cost = { crystal1 = math.floor( 1.5 ^ i ) }, level_up = { '硬铁剑'..(i+1) }, level = i+3, force_att_max = 2
    })
    if i == 10 then swordDef.level_up = {} end
    table.insert( EquipmentDefList, swordDef )
end

-- 斩剑系列
for i = 1, 8, 1 do
    local swordDef = merge( copy(EQUIPMENT_SWORD1), {
        id = '斩剑'..i, img = 'spr_weapon/sword_zhan.spr', category = '斩剑', 
        descDetails='< 狂暴 >\n主动攻击之后，会接着进行两次攻击。\n\n< 暴击 >\n有暴击的机率。', desc = '斩剑'..i, cost = { crystal1 = 10 }, btn = '升级', att = 4 + i, energy_max = 25 + i * 5, recharge_cost = { crystal1 = math.floor( 1.1 ^ i ) }, level_up = { '斩剑'..(i+1) }, level = i+3, force_att_max = 2
    })
    if i == 8 then swordDef.level_up = {} end
    table.insert( EquipmentDefList, swordDef )
end

-- 二段剑系列
for i = 1, 8 do
    local swordDef = merge( copy(EQUIPMENT_SWORD1), {
        -- 重铸（随机消耗三种不同颜色的水晶，合计6个。可过度充能，范围2格，充能3-5，充能花费4-8）
        id = '二段剑'..i, img = 'spr_weapon/sword_erduanjian.spr', category = '二段充能剑', desc = '二段充能剑'..i, cost = { crystal1 = 12 }, btn = '升级', att = 2 + i, energy_max = math.floor( 15 + 5 * i * 0.8 ) * 2, energy_over_max = math.floor( 5 + i * 1.8 ), charge_buff = BUFF_WEAPON_DOUBLE_CHARGE_SWORD,
        recharge_cost =  { crystal1 = math.floor( 1.5 ^ i ) }, level_up = { '二段剑'..(i+1) },
        descDetails='< 狂暴 >\n主动攻击之后，会接着进行两次攻击。\n\n< 二段充能 >\n在充能为白色区间时，有大的攻击范围。' , level = i+2, force_att_max = 2
    })
    if i == 8 then swordDef.level_up = {} end
    table.insert( EquipmentDefList, swordDef )
end

-- 彩虹剑系列
for i = 1, 6, 1 do
    local swordDef = merge( copy(EQUIPMENT_SWORD1), {
        id = '彩虹剑'..i, img = 'spr_weapon/sword_caihong.spr', category = '彩虹剑', desc = '彩虹剑'..i, cost = { crystal1 = 12 }, btn = '升级', att = math.floor( 3 + i * 0.8 ), energy_max = math.floor( 15 + 5 * i * 0.8 ), recharge_cost =  { crystal1 = math.floor( 1.5 ^ i ) },
        descDetails='< 狂暴 >\n主动攻击之后，会接着进行两次攻击。\n\n< 彩虹 >\n其它宝石的掉率会比通常更高，但是相对的，升级该武器则变得比通常困难。' , level = i+2, force_att_max = 2
    })
    if i == 6 then swordDef.level_up = {} end
    table.insert( EquipmentDefList, swordDef )
end

-- 普通的冲刺矛       玩家攻击后会不由自主地往前方再进行一次移动或攻击
for i = 1, 10, 1 do
    local def = {
        id = '冲刺矛'..i, img = 'spr_weapon/spearbase.spr', etype = 'weapon', category = '冲刺矛', btn = '打造', min_att = 1, att_terrain = 1, range = { { x = 0, y = 1 } }, 
        descDetails='< 突刺 >\n在主动攻击之后，会往前方再攻击或移动一次。', desc = '冲刺矛'..i, cost = { crystal2 = math.floor(5 * 1.2^i) }, att = math.floor(4 + i * 1.2), 
        energy = 10, energy_max = 5 + i * 5, 
        force_move = 0, force_move_max = 2, cur_force_move = nil, 
        recharge_cost = { crystal2 = math.floor( 1.1 ^ i ) }, level_up = { '冲刺矛'..(i+1) }, level = i,
    }
    if i == 10 then def.level_up = {} end
    table.insert( EquipmentDefList, def )
end

-- 普通的弓箭     视野宽阔移动方向前方三格有敌人则会进行射击。在进程射击的话会收到伤害
for i = 1, 10, 1 do
    local def = {
        id = '弓箭'..i, category = '弓箭', img = 'spr_weapon/bowbase.spr', etype = 'weapon', btn = '打造', 
        sight = 3.5,
        range = { { x = 0, y = 1 },{ x = 0, y = 2 },{ x = 0, y = 3 } }, range_weak = { { x = 0, y = 1 } },
        descDetails='< 远程 >\n能攻击到3格之内的敌人。\n\n< 不善近战 >\n在近战范围内攻击敌人，自己也会受到伤害。', desc = '弓箭'..i, cost = { crystal3 = math.floor(5 * 1.2^i) }, att = math.floor(3 + i * 1), energy = 10, energy_max = 5 + i * 5, recharge_cost = { crystal3 = math.floor( 1.1 ^ i ) }, level_up = { '弓箭'..(i+1) }, level = i
    }
    if i == 10 then def.level_up = {} end
    table.insert( EquipmentDefList, def )
end

-- 普通的劈山斧   劈山斧，地形破坏，攻击前方三格，低充能，有cd。
for i = 1, 10, 1 do
    local def = {
        id = '劈山斧'..i, img = 'spr_weapon/axebase.spr', etype = 'weapon', category = '劈山斧', desc = '劈山斧1', cost = { crystal4 = math.floor(5 * 1.2^i) }, btn = '打造', att = math.floor(4 + i * 2), min_att = 2, att_terrain = 3, energy_max = math.floor( 2.5 + i * 2.5), energy = 5, recharge_cost = { crystal4 = math.floor( 1.1 ^ i ) * 2}, range = { { x = 0, y = 1 }, { x = -1, y = 1 }, { x = 1, y = 1 } }, is_aoe = true, att_self_stun = 1,
        descDetails='< 横扫 >\n能攻击前方三格\n\n< 沉重 >\n攻击之后，会需要一回合重新摆好架势。', level_up = { '劈山斧'..(i+1) }, level = i
    }
    if i == 10 then def.level_up = {} end
    table.insert( EquipmentDefList, def )
end

AllBaseCategories = { '劈山斧1', '弓箭1', '冲刺矛1', '剑1' }
AllLevelUpCategories = { '彩虹剑1', '二段剑1', '斩剑1', '硬铁剑1' }

FindEquipmentById = function( id )
    for k,v in ipairs( EquipmentDefList ) do
        if id == v.id then return v end
    end
end

FindLevelUpsById = function( id )
    local result = {}
    for k,v in ipairs( EquipmentDefList ) do
        if id == v.id then 
            for kk, vv in ipairs( v.level_up ) do
                table.insert( result, FindEquipmentById( vv ) )
            end
        end
    end
    return result
end

FilterEquipmentByCrafted = function( craftedIds )
    local crafted = {}
    local craftedLevelUp = {}
    local levelUpMissed = {}
    for k,v in ipairs( EquipmentDefList ) do 
        if exists( craftedIds, v.id ) then
			table.insert( crafted, v.id )
            local anyLevelupCrafted = false
            -- check if any level up items have been crafted
            for kk,vv in ipairs( v.level_up ) do
                if  exists( craftedIds, vv ) then
                    anyLevelupCrafted = true
                end
            end
            -- add available level ups
            if anyLevelupCrafted == false then
                for kk,vv in ipairs( v.level_up ) do
                    if not exists( craftedIds, vv ) then
                        table.insert( craftedLevelUp, vv )
                    end
                end
            else
                for kk,vv in ipairs( v.level_up ) do
                    if not exists( craftedIds, vv ) then
                        table.insert( levelUpMissed, vv )
                    end
                end
            end
        end
    end
    return crafted, craftedLevelUp, levelUpMissed
end

FindRequirement = function( id )
    for k,v in ipairs(EquipmentDefList) do
        if exists( v.level_up, id ) then 
            return v.id
        end
    end
    return nil
end