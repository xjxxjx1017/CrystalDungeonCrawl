require 'game'
require 'ui3'
require 'map_generator'
require 'background'
require 'analysis'
require 'units/projectile'
require 'camera'
require 'mainmenu'

-- resources
lanapixel = Font.new('fonts/LanaPixel.ttf', 26)   -- 中文像素字体，13 的倍数效果较好。
bank = nil

DEBUG = false -- full player vision, better weapon, more crystals
DEBUG_MORE_CRYSTAL = false
DEBUG_POSITION = false
DEBUG_MAP = false
DEBUG_WEAPON = false
DEBUG_UNIT = false
DEBUG_USE_TEST_LEVEL = false
DEBUG_RENDER_ORDER = false
DEBUG_FAST_MODE = false
DEBUG_FRAME = false
DEBUG_FRAME_RATE = false
DEBUG_HIDE_TERRAIN = false
DEBUG_UI_LAYOUT = false
DEBUG_ANALYSIS_LEVEL = false
DEBUG_ANALYSIS_ALL = false
DEBUG_LEVEL = false
DEBUG_CONSOLE = false -- input some common through the UI ( e.g. to kill an unit )
DEBUG_UNIT_GENERATE = false -- debug the unit generation logic, including level balance
DEBUG_KEYS = true -- enable cheat keys
DEBUG_ADJUST_PARAMS = false -- use UI to adjust particle systems
TEST_MAP = 'level/test2.map'

tileH = 32
tileW = 32
bg = Background.new()

initStep = 0

BaseScene = class({
	ctor = function( self )
	end,
	setup = function( self )
	end,
	update = function( self, delta )
	end,
})

SceneMainMenu = class({
	ctor = function( self )
        BaseScene.ctor(self)
	end,
	setup = function( self )
		mainmenu:setup()
	end,
	update = function( self, delta )
		mainmenu:update( delta )
	end,
}, BaseScene)

SceneGameMode = class({
	ctor = function( self )
        BaseScene.ctor(self)
	end,

	setup = function( self )
		Debug.setTimeout( 180 )

		-- Load bg
		bg:setup()
		-- Load levels
		if DEBUG_MAP then
			mapGenerator:setup()
			mapGenerator.debug_module = mapGenerator:loadMapStructure( g )
		else
			mapGenerator:setup()
		end	
		-- Load map
		if DEBUG_MAP == false then
			game:setup()
		end	
		-- Load ui
		if DEBUG_MAP == false then
			ui:setup()
		end	
	
		Debug.setTimeout( 60 )
		local canvasWidth, canvasHeight = Canvas.main:size()
		local px, py = game.player:getRealPos()
		mainCamera:setCameraPos( ui.mox + px - canvasWidth * 0.5, ui.moy + py - canvasHeight * 0.5 )
	end,

	update = function( self, delta )
		if DEBUG_FRAME_RATE then
			if delta > 0.1 then
				warn('frame rate very low: '.. delta)
			elseif delta > 0.05 then
				-- warn('frame rate low: '.. delta)
			end
		end
		if not DEBUG_ANALYSIS_ALL then
			if DEBUG_MAP then
				mapGenerator:printDebugModule()
			else
				mainCamera:update(delta)
				game:update(delta)
				bg:update(delta)
				camera()
				ui:update(delta)
				mainCamera:update(delta)
				projectileManager:update(delta)
				projectileManager:render()
			end	
		end
	end,
}, BaseScene)


curScene = nil
function setup()
	cls(Color.new(0,0,0))
	Canvas.main:resize(960, 640)

	math.randomseed(DateTime.ticks())

	if DEBUG_ANALYSIS_ALL then
		UnitMaster_Analysis_Export_All()
	else
		curScene = SceneMainMenu.new()
		curScene:setup()
	end

	font(lanapixel)
	sync()
end

function update(delta)
	if curScene == nil then return end
	curScene:update( delta )
end


