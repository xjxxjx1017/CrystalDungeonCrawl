require 'code/class'
require 'libs/beGUI/beGUI'
require 'libs/beGUI/customizedTheme'
require 'code/util'
require 'code/keycode'
require 'map_generator'

local tileSize = 32
local tileCount= MapTile_WH
local tileCountNoCamera= 16
local totalH = 640
local totalW = 960
local margin = 8 
local lineHeight = 30
local mapPaddingW = 70
local mapPaddingH = tileSize * 2
local mapOffsetX = totalW / 2 - tileSize * tileCount / 2
local mapOffsetY = mapPaddingH
local mapOffsetXNoCamera = totalW / 2 - tileSize * tileCountNoCamera / 2
local mapOffsetYNoCamera = mapPaddingH
local mapSize = tileSize * tileCount
local btnWUnit = 80

COLOR_TINT = Color.new( 0, 172, 186)
COLOR_TINT_50 = Color.new( 0, 172, 186, 128)
COLOR_DARK_BLUE = Color.new( 5, 26, 36)
COLOR_RED = Color.new( 255, 15, 0)
COLOR_ORANGE = Color.new( 243, 129, 4)
COLOR_ORANGE_50 = Color.new( 243, 129, 4, 128)
COLOR_PURPLE = Color.new( 148, 157, 224)
COLOR_WHITE = Color.new( 255, 255, 255)
COLOR_GREY = Color.new( 40, 40, 40)
COLOR_YELLOW_TRANS = Color.new( 255, 255, 0, 160 )

local texUI_backdrop_sample = Resources.load('res/UI_backdrop_sample.png')
local texUI_backdrop = Resources.load('res/UI_backdrop.png')
local texUI_bank7_ui = Resources.load('res/bank7_ui.png')
local texUI_bank7 = Resources.load('res/bank7.png')
local texUI_tile_ui = Resources.load('res/tile_ui.png')
local texUI_numbers = Resources.load('res/numbers.png')
local texUI_crystal_coin = Resources.load('res/crystal_coin.png')

local P = beGUI.percent -- Alias of percent.

adjust = {256, 64, 64, 256, 64 + 3, 300, 300, 50 }

UI_DebugConsole = class({
    widget = nil,
    container = nil,

    ctor = function(self)
    end,

    setup = function(self, container)
        self.container = container
        if DEBUG_ADJUST_PARAMS then
            for i = 1,#adjust do
                local xx = math.floor( i / 10 )
                local yy = i % 10
                container:addChild(
                    beGUI.InputBox.new('', 'Adjust'..i..": "..adjust[i])
                        :put(margin + 7 * 32 + ( 7 * 32 ) * xx, lineHeight * ( 0 + yy ) + margin * ( 0 + yy ) )          -- X: 0, Y: 0.
                        :resize(P(20), lineHeight) -- W: 100%, H: 23.
                        :on('changed', function (sender, value)
                            adjust[i] = value
                            print('adjust value '..i.. ': '.. value)
                        end)
                )
            end
        end
        if DEBUG_CONSOLE then
            self.widget = container:addChild( beGUI.InputBox.new('', 'console')
                :setId('debug_console')
                :put(margin + 7 * 32, lineHeight * ( 2 + 0 ) + margin * ( 3 + 1 ) )          -- X: 0, Y: 0.
                :resize(P(20), lineHeight) -- W: 100%, H: 23.
                :on('changed', function (sender, value)
                    print('adjust value '.. value)
                    local args = mysplit( value )
                    if args[1] == 'kill' and #args >= 3 then
                        for k,v in ipairs( game:getBoard( args[2], args[3] ) ) do
                            if v.cfg.can_player_attack then v:killThis( game.player ) end
                        end
                    end
                end))
        end
    end,
})
ui_debugConsole = UI_DebugConsole.new()

UI_Pool = class({
    pool = {},

	ctor = function(self)
	end,
	
    getRes = function( self, res, playSprFrame )
        if self.pool[res] == nil then
            self.pool[res] = Resources.load( res )
            if playSprFrame ~= nil and self.pool[res] ~= nil then
                self.pool[res]:play( playSprFrame )
            end
        end
        return self.pool[res]
    end,
})
ui_pool = UI_Pool.new()


UI_ShowNumber = function( sprX, sprY, n, zoom, color )
    if color == nil then
        color = Color.new(255, 255, 255)
    end
	if n == nil then return end
    if n >= 10 then
        tex( texUI_numbers, sprX, sprY, 5 * zoom, 7 * zoom, math.floor(n/10) * 5, 0, 5, 7, 0, Vec2.new(0.5, 0.5), false, false, color )
        tex( texUI_numbers, sprX + 5 * zoom, sprY, 5 * zoom, 7 * zoom, math.floor( n % 10 ) * 5, 0, 5, 7, 0, Vec2.new(0.5, 0.5), false, false, color )
    else
        tex( texUI_numbers, sprX + 3 * zoom, sprY, 5 * zoom, 7 * zoom, math.floor( n % 10 ) * 5, 0, 5, 7, 0, Vec2.new(0.5, 0.5), false, false, color )
    end
end

UI_Equipment_Render = function( x, y, w, h, cfg, res, iconResIndex, number, barResX, barResY, barValue, barMax )
    local adjust = {32, 26, 7, 8, -46, 8, 4, 0, 2.5, -18, -20, 73, 90, -6}
    x = x + adjust[7]
    y = y + adjust[8]
    local p = barValue / barMax
    -- show equipment icon
    spr( res, x, y, w, h )
    -- show the right down corner icon
    if number > 0 then
        tex( texUI_tile_ui, x + adjust[1], y + adjust[2], 64, 64, 32 * iconResIndex, 0, 32, 32 )
        UI_ShowNumber( x + 64 + adjust[3], y + 64 + adjust[4], number, 2 )
    end
    -- show number
    UI_ShowNumber( x + adjust[11], y + adjust[12], barMax, 2 )
    UI_ShowNumber( x + adjust[11], y + adjust[12] + adjust[10], barValue, 2 )
    -- show the bar
    tex( texUI_bank7_ui, x + adjust[5], y + adjust[6] + 32 * (1 - p) * adjust[9], 32, 32 * adjust[9] * p, 
        32 * barResX, barResY * 32 + 32 * (1 - p) * 3, 32, 32 * 3 * p )

    -- mouse hover event
    UI_Clickable( Rect.new( x, y, x + w, y + h ), Rect.new( x, y + adjust[13], x + w + adjust[14], y + 3 + adjust[13] ), 
    function()
        ui_itemDetail.curDetail = cfg
    end, nil )
end

UI_Buy_Render = function( x, y, iconResIndexX, iconResIndexY, priceResIndexX, priceResIndexY, cost, canAfford, canPayPartial )
    local adjust = {14, 24 , 16}
    local color = nil
    if not canAfford then
        if canPayPartial then
            color = Color.new( 255, 125, 0 )
        else
            color = Color.new( 255, 0, 0 )
        end
    end
    local coinColor = Equipment_GetCrystalColor( cost )
    -- show crystal
    tex( texUI_crystal_coin, x + adjust[1], y + 2, 32, 32, 0, 0, 0, 0, 0, Vec2.new(0.5, 0.5), false, false, coinColor )
    -- show icon
    tex( texUI_bank7_ui, x, y, 32, 32, iconResIndexX * 32 , iconResIndexY * 32, 32, 32 )
    -- show number
    UI_ShowNumber( x + adjust[2], y + adjust[3], Crystals_sum(cost), 2, color )
end

UI_Icon_Render = function( x, y, iconResIndexX, iconResIndexY, w, h )
    -- show icon
    tex( texUI_bank7_ui, x, y, 32 * w, 32 * h, iconResIndexX * 32 , iconResIndexY * 32, 32 * w, 32 * h )
end

UI_Clickable = function( clickArea, highlightArea, onHover, onClick )
    local xx, yy, tb1 = mouse(1)
    if xx > clickArea.x0 and xx < clickArea.x1 and yy > clickArea.y0 and yy < clickArea.y1 then
        if onHover ~= nil then
            onHover()
        end
        blend( Canvas.BlendModeAdd )
        rect(highlightArea.x0, highlightArea.y0, highlightArea.x1, highlightArea.y1, true, COLOR_YELLOW_TRANS)
        if mouseClick(tb1) and onClick ~= nil then
            onClick()
        end
        blend()
    end
end

UI_ItemDetail = class({
    curDetail = nil,
    container = nil,

    ctor = function(self)
    end,

    setup = function(self, container)
        self.container = container
        container:addChild(
            beGUI.MultilineLabel.new( '' )
                :setId('item_details')
                :put( margin + ui.moxNoCamera, margin + ui.moyNoCamera)
                :resize( tileSize * tileCountNoCamera - margin * 2, tileSize * tileCountNoCamera - margin * 2 )
        )
    end,

    render = function(self)
		if container == nil then return end
        local details = self.container:find('item_details')
        if self.curDetail == nil then 
            details:setVisible( false ) 
			return
        end
        rect(ui.moxNoCamera, ui.moyNoCamera, ui.moxNoCamera + tileSize * 16 , ui.moyNoCamera + tileSize * 16, true, COLOR_GREY)
        local d = FindEquipmentById( self.curDetail.id )
        details:setValue( Equipment_GetDetailDescription(d) ):setVisible( true )
    end,
})
ui_itemDetail = UI_ItemDetail.new()

UI_ItemList = class({
    page  = 1,
    totalPage = 1,
    pageItemMax = 11,
    lastItemList = {},

    ctor = function(self)
    end,

    render = function(self)
        local itemlist = self.lastItemList
        for i,ee in ipairs( itemlist ) do
            if i < ( self.page * self.pageItemMax + 1 ) and i > (self.page-1) * self.pageItemMax then
                local iconResIndex, number, barResX, barResY, barValue, barMax = 4, ee.cfg.att, 0, 0, ee.cfg.energy, ee.cfg.energy_max
                if ee.cfg.energy_power_max > 0 then
                    iconResIndex, number, barResX, barResY, barValue, barMax = 3, ee.cfg.energy_power_max, 1, 0, ee.cfg.energy_power, ee.cfg.energy_power_max
                end
                local canAfford = Equipment_canAfford( ee.cfg )
                printOnce('', '', row, ee.cfg.id, res, iconResIndex, number, barResX, barResY, barValue, barMax, 
                    isEquipped, isSwitchable, isUpgrade, isNew, isLocked, canAfford)
                -- row, res, iconResIndex, number, barResX, barResY, barValue, barMax, isEquipped, isSwitchable, isUpgrade, isNew, isLocked
                self:_render( i-1, ee.cfg, ui_pool:getRes( ee.cfg.img, 'idle' ), iconResIndex, number, barResX, barResY, barValue, barMax, ee.isEquipped, ee.isSwitchable, ee.isUpgrade, ee.isNew, ee.isLocked, canAfford )
            end
        end
    end,

    _render = function( self, row, cfg, res, iconResIndex, number, barResX, barResY, barValue, barMax, 
        isEquipped, isSwitchable, isUpgrade, isNew, isLocked, canAfford )
    
        local adjust = {44, 0, 52, 12, -4, 4, -30, 
            0, 0.8, -155, 80, 41, 52, 136, 
            40, 32}

        local x = totalW + adjust[10]
        local y = adjust[11] + row * adjust[12]
        
        x = x + adjust[7]
        y = y + adjust[8]
        -- show equipment icon
        spr( res, x, y, 32, 32 )
        if not isLocked then
            if canAfford then
                text( cfg.desc, x + adjust[1], y + adjust[2] )
            else
                text( cfg.desc, x + adjust[1], y + adjust[2], Color.new( 125, 125, 125 ) )
            end
            -- show equipped or change
            if isEquipped then
                UI_Icon_Render( x + adjust[14], y, 3, 0, 1, 1 )
            elseif isSwitchable then
                UI_Icon_Render( x + adjust[14], y, 4, 0, 1, 1 )
            end
            -- show upgrade or craft
            if isUpgrade then
                UI_Buy_Render( x + adjust[14], y, 5, 0, 7, 0, cfg.cost, canAfford, false )
            elseif isNew then
                UI_Buy_Render( x + adjust[14], y, 6, 0, 7, 0, cfg.cost, canAfford, false )
            end
        else
            text( "? ? ?", x + adjust[1], y + adjust[2], Color.new( 125, 125, 125 ) )
            -- show lock
            UI_Icon_Render( x + adjust[14], y, 8, 2, 1, 1 )
        end

        -- mouse hover event
        if not isLocked then
            UI_Clickable( Rect.new( x, y, x + adjust[14] + adjust[15], y + adjust[12] ), Rect.new( x, y + adjust[16] - row, x + adjust[14] + adjust[15], y + 3 + adjust[16] ),
            function()
                ui_itemDetail.curDetail = cfg
            end,
            function()
                if (( isNew or isUpgrade ) and canAfford) or isSwitchable  then
                    game:upgradeEquipment( cfg, isSwitchable )
                    game.player:changeState()
                    self:update()
                    game.player.stun = game.player.stun + 3
                end
            end )
        end

    end,
    
    _updateResult = { cfg = nil, isEquipped = false, isSwitchable = false, isUpgrade = false, isNew = false, isLocked = false },
    update = function( self )
        local fullList = {}
        local fullIds = {}
        local equipped = { game.weapon.cfg.id, game.shield.cfg.id }
        local crafted, craftedLevelUp, levelUpMissed = game:filterEquipmentByCrafted()
    
        for k,n in ipairs( levelUpMissed ) do
            table.insert( fullIds, n )
        end

        for k,n in ipairs( crafted ) do
            if not exists( equipped, n ) then
                local ee = merge( EquipmentDefault, copy( FindEquipmentById( n ) ) );
                local isLevelUped = false
                for klevelup, nlevelup in ipairs( ee.level_up ) do
                    if exists( crafted, nlevelup ) then
                        isLevelUped = true
                    end
                end
                if isLevelUped == false then
                    table.insert( fullList, { cfg = ee, isEquipped = false, isSwitchable = true, isUpgrade = false, isNew = false, isLocked = false } )
                end
                table.insert( fullIds, n )
            end
        end
    
        for k,n in ipairs( craftedLevelUp ) do
            local ee = merge( EquipmentDefault, copy( FindEquipmentById( n ) ) );
            table.insert( fullList, { cfg = ee, isEquipped = false, isSwitchable = false, isUpgrade = true, isNew = false, isLocked = false } )
            table.insert( fullIds, n )
        end

        local lockedList = {}
        -- find all the next next level up categories
        for k,n in ipairs( craftedLevelUp ) do
            local ee = merge( EquipmentDefault, copy( FindEquipmentById( n ) ) );
            for knn, nnn in ipairs( ee.level_up ) do
                if exists( AllLevelUpCategories, nnn ) then
                    local eee = merge( EquipmentDefault, copy( FindEquipmentById( nnn ) ) );
                    table.insert( lockedList, { cfg = eee, isEquipped = false, isSwitchable = false, isUpgrade = false, isNew = false, isLocked = true } )
                end
            end
        end

        local newCategoryList = {}
        -- show all the missing base categories
        for k,n in ipairs( AllBaseCategories ) do
            local ee = merge( EquipmentDefault, copy( FindEquipmentById( n ) ) );
            if not exists( crafted, n ) then
                table.insert( newCategoryList, { cfg = ee, isEquipped = false, isSwitchable = false, isUpgrade = false, isNew = true, isLocked = false } )
            end
        end
        fullList = concat( fullList, newCategoryList )
        fullList = concat( fullList, lockedList )
        self.lastItemList = fullList
    end,
})
ui_itemList = UI_ItemList.new()

UI_Popup = class({
    ispopup = false,
    popup = nil,

    ctor = function(self)
    end,


    setup = function(self)
        self.popup = beGUI.Widget.new():put(0, 0):resize(P(100), P(100))
    end,


    render = function(self, delta)
        if self.ispopup then
			rect(0, 0, totalW, totalH, true, Color.new(40, 40, 40, 180))
            font(theme['font'].resource)
            self.popup:update(theme, delta)
            font(lanapixel)
        end
    end,

    open = function(self, title, messages, button, onConfirm)
        self.ispopup = true
        local onClick = function()
            print('Popup: remove')
            self.popup:clearChildren()
            self.ispopup = false
            onConfirm()
        end

        local box = beGUI.Widget.new()
            :setId('popupcontainer')
            :put(0, 0)     -- X: 27%, Y: 15.
            :resize(totalW - 30, totalH - 30) -- W: 45%, H: 290.
        for k,v in ipairs( messages ) do
            local font = 'font_white'
            if k == #messages then
                font = 'font_alert'
            end
            box:addChild( beGUI.Label.new(v, 'center', false, font)
                :put(0, totalH / 2 - lineHeight - #messages * lineHeight / 2 + k * lineHeight)
                :resize(totalW, lineHeight)
            )
        end
        box:addChild(
            beGUI.Button.new(button)
                :setId('popup_exit')
                :anchor(0, 0)      -- X: left, Y: bottom.
                :put((totalW - btnWUnit) / 2, totalH / 2 - lineHeight - #messages * lineHeight / 2 + #messages * lineHeight + lineHeight * 2)    -- X: -50%, Y: 0.
                :resize(btnWUnit, lineHeight) -- W: 48%, H: 23.
                :on('clicked', function (sender)
                    onClick()
                end)
        )
        self.popup:addChild( box )
    end,
})
ui_popup = UI_Popup.new()

UI_RenderCrystals = function()
    local adjust = { 16, 590, 16, 16, 42 }
    local x, y = adjust[1], adjust[2]
    n = 0
    for k,v in pairs(CRYSTALS) do
        local crystal = game.currency[k]
        local cs = {}
        cs[k] = crystal
        local color = Equipment_GetCrystalColor( cs )
        tex( texUI_crystal_coin, x + n * adjust[5], y, 32, 32, 0, 0, 0, 0, 0, Vec2.new(0.5, 0.5), false, false, color )
        -- show number
        UI_ShowNumber( x + adjust[3] + n * adjust[5], y + adjust[4], crystal, 2, color )
        n = n + 1
    end
end

UI3 = class({
    -- map position offsets
    mox = mapOffsetX,
    moxNoCamera = mapOffsetXNoCamera,
    moy = mapOffsetY,
    moyNoCamera = mapOffsetYNoCamera,
    root = nil,
	backgroundMask = nil,

    ctor = function(self)
    end,

    setup = function (self)
        self.root = beGUI.Widget.new():put(0,0):resize(P(100), P(100))

		self.backgroundMask = Resources.load('spr/background_mask.spr')
		self.backgroundMask:play('idle')

        ui_debugConsole:setup( self.root )
		ui_itemDetail:setup( self.root )
        ui_popup:setup()

        theme = customizedTheme.default()
    end,
    
    update = function (self, delta)
        ui_itemDetail.curDetail = nil

		-- spr( self.backgroundMask, 0, 0, 960, 640 )

        tex( texUI_backdrop, 0, 0 )

        UI_RenderCrystals()

        -- render current equipments on the left hand 
        UI_Equipment_Render( 48, 64, 96, 96, game.shield.cfg, ui_pool:getRes( game.shield.cfg.img, 'idle' ), 3, 0, 1, 0, game.shield.cfg.energy_power, game.shield.cfg.energy_power_max )
        UI_Equipment_Render( 48, 64 + 96 + 32, 96, 96, game.weapon.cfg, ui_pool:getRes( game.weapon.cfg.img, 'idle' ), 4, game.weapon.cfg.att, 0, 0, game.weapon.cfg.energy, game.weapon.cfg.energy_max )

        -- render the repair button
        local adjust = {32, 8}
        local x, y = 48 + adjust[1], 96 * 3 + adjust[2]
        local recargeFullCost = Crystals_multiply( game.weapon.cfg.recharge_cost, game.weapon.cfg.energy_max - game.weapon.cfg.energy )
        UI_Buy_Render( x, y, 2, 0, 7, 0, recargeFullCost, Crystals_canAfford( recargeFullCost ), true )

        UI_Clickable( Rect.new( x, y, x + 64, y + 64 ), Rect.new( x, y + 32, x + 32, y + 32 + 3 ), nil, function()
            print('充能')
            game:chargeWeapon()
            game.player.stun = game.player.stun + 3
        end )

        -- render the equipment list on the right hand
        ui_itemList:render()

        -- render item details, if mouse is hovering any
        ui_itemDetail:render()

        ui_popup:render( delta)

        font(theme['font'].resource)
        self.root:update(theme, delta)
        font(lanapixel)
    end,
	
	updateCraftPanel = function(self, isForce)
        ui_itemList:update()
	end,

    openPopup = function ( self, title, messages, button, onConfirm )
        ui_popup:open( title, messages, button, onConfirm )
    end
})

ui = UI3.new()