require 'code/class'
require 'libs/beGUI/beGUI'
require 'libs/beGUI/customizedTheme'
require 'code/util'
require 'code/keycode'
require 'map_generator'

local tileSize = 32
local tileCount= MapTile_WH
local tileCountNoCamera= 16
local totalH = 640
local totalW = 960
local margin = 8 
local lineHeight = 30
local mapPaddingW = 70
local mapPaddingH = tileSize * 2
local mapOffsetX = totalW / 2 - tileSize * tileCount / 2
local mapOffsetY = mapPaddingH
local mapOffsetXNoCamera = totalW / 2 - tileSize * tileCountNoCamera / 2
local mapOffsetYNoCamera = mapPaddingH
local mapSize = tileSize * tileCount
local btnWUnit = 80

COLOR_TINT = Color.new( 0, 172, 186)
COLOR_TINT_50 = Color.new( 0, 172, 186, 128)
COLOR_DARK_BLUE = Color.new( 5, 26, 36)
COLOR_RED = Color.new( 255, 15, 0)
COLOR_ORANGE = Color.new( 243, 129, 4)
COLOR_ORANGE_50 = Color.new( 243, 129, 4, 128)
COLOR_PURPLE = Color.new( 148, 157, 224)
COLOR_WHITE = Color.new( 255, 255, 255)
COLOR_GREY = Color.new( 40, 40, 40)
COLOR_YELLOW_TRANS = Color.new( 255, 255, 0, 160 )

local texUI_backdrop_sample = Resources.load('res/UI_backdrop_sample.png')
local texUI_backdrop = Resources.load('res/UI_backdrop.png')
local texUI_bank7_ui = Resources.load('res/bank7_ui.png')
local texUI_bank7 = Resources.load('res/bank7.png')
local texUI_tile_ui = Resources.load('res/tile_ui.png')
local texUI_numbers = Resources.load('res/numbers.png')
local texUI_crystal_coin = Resources.load('res/crystal_coin.png')

local P = beGUI.percent -- Alias of percent.


ui_debugConsole_mainmenu = UI_DebugConsole.new()

UI_MenuButton = function( row, txt, onClick)
    local adjust = {192, 32, 32, 192, 32 + 3, 325, 250, 50 }
    local x, y = adjust[6], adjust[7]
    text( txt, x, y + row * adjust[8] )
    UI_Clickable( Rect.new( x, y + row * adjust[8], x + adjust[1], y + row * adjust[8] + adjust[2] ), Rect.new( x, y + row * adjust[8] + adjust[3], x + adjust[4], y + row * adjust[8] + adjust[5] ), nil, onClick )
end

UI_Title = function( txt )
    local adjust = {192, 32, 32, 192, 32 + 3, 325, 250, 50 }
    local x, y = adjust[6], adjust[7]
    text( txt, x, y + adjust[8] * -2, COLOR_RED )
end

MainMenu = class({
    -- map position offsets
    mox = mapOffsetX,
    moxNoCamera = mapOffsetXNoCamera,
    moy = mapOffsetY,
    moyNoCamera = mapOffsetYNoCamera,
    root = nil,
    step = 'mainmenu',
    toLoad = nil,

    ctor = function(self)
    end,

    setup = function (self)
        self.root = beGUI.Widget.new():put(0,0):resize(P(100), P(100))

        ui_debugConsole_mainmenu:setup( self.root )
        self.step = 'mainmenu'

        theme = customizedTheme.default()
    end,
    
    update = function (self, delta)

        if self.step == 'mainmenu' then
            UI_Title( '水晶锻造者 - 烈火的冒险迷宫' )

            UI_MenuButton( 0, '清空记录', function() 
                print('清空记录')
            end )
            UI_MenuButton( 1, '开始新游戏', function() 
                self.step = 'modeselect'
            end )
            UI_MenuButton( 2, '履历浏览', function() 
                print('履历浏览')
            end )
            UI_MenuButton( 3, '选项', function() 
                print('选项')
            end )
            UI_MenuButton( 4, '退出', function() 
                exit() 
            end )

        elseif self.step == 'modeselect' then       
            UI_Title( '模式选择 (加载需要2分钟，请耐心等待）' )

            UI_MenuButton( 0, '第零个模式 - 测试模式', function() 
                print('第零个模式 - 测试模式')
                self.step = 'loading' 
                self.toLoad = function()
                    local mode = SceneGameMode.new()
                    mode:setup()
                    curScene = mode
                end
            end )
            UI_MenuButton( 1, '第一代模式 - 大乱斗', function() 
                print('第一代模式 - 大乱斗')
                self.step = 'loading' 
                self.toLoad = function()
                    local mode = SceneGameMode.new()
                    mode:setup()
                    curScene = mode
                end
            end )
            UI_MenuButton( 2, '第二个模式 - 标准模式', function() 
                print('第二个模式 - 标准模式')
                self.step = 'loading' 
                self.toLoad = function()
                    local mode = SceneGameMode.new()
                    mode:setup()
                    curScene = mode
                end
            end )
            UI_MenuButton( 3, '返回', function() 
                self.step = 'mainmenu' 
            end )
        elseif self.step == 'loading' then 
            UI_Title( '加载中...' )

            UI_MenuButton( 0, '请耐心的等待3分钟', nil )

            if self.toLoad ~= nil then
                self.toLoad()
                self.toLoad = nil
            end
        end

        font(theme['font'].resource)
        self.root:update(theme, delta)
        font(lanapixel)
    end,
})

mainmenu = MainMenu.new()


