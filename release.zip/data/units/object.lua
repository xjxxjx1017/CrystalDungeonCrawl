require 'code/class'
require 'code/keycode'
require 'code/util'
local Tween = require 'code/tween' -- See https://github.com/kikito/tween.lua.

local txtBank7 = Resources.load('res/bank7.png')
local txtNumber = Resources.load('res/numbers.png')
local sprUnitBase = Resources.load('spr_ui/tile_unit_base.spr')
local sprNumber = Resources.load('spr_ui/numbers.spr')

--[[
	Object is a class that handles basic grid based objects ( more likely to be units ). 
	It has two pairs of position values, one for rendering and the other for logic.
	It can play out the animation of attack and move
	It handles the tweens of attack and move, can check whether the unit's turn is finished.
	It also holds the units config
]]
Object = class({
	x1 = 0, -- anime posX
	y1 = 0, -- anime posY
	x2 = 0, -- logic posX
	y2 = 0, -- logic posY
	spr_ = nil,
	sprLevel = nil,
	tw = nil,
	actions = {},
	id = '',
	cfg = nil,
	isShow = true,
	xOffset = 0,
	yOffset = 0,
	
	ctor = function ( self, id, x, y, cfg, xOffset, yOffset )
		self.id = id .. '.' .. x .. '.' .. y
		self.cfg = cfg or Unitcfg.new()
		self:setAllpos( x, y )
		self.xOffset = xOffset
		self.yOffset = yOffset
		if self.cfg.img ~= nil then
			imgSrc = 'spr/' .. self.cfg.img ..  '.spr'
			self.spr_ = Resources.load(imgSrc)
			self.spr_:play('idle')
		end
		-- if self.cfg.curLevel > 0 or self.cfg.curLevel < 11 then
		-- 	self.sprLevel = Resources.load('spr_ui/numbers')
		-- 	self.sprLevel:play(''.. (self.cfg.curLevel%10))
		-- end
	end,

	update = function( self, delta )
		if self.tw ~= nil then
			self.tw:update(delta)
		end
		for k,v in ipairs( self.actions ) do
			v:update(delta)
		end
		for k = #self.actions, 1, -1 do
			local vv = self.actions[k]
			if vv.finished == true then
				table.remove( self.actions, k )
			end
		end
	end,

	animeAttack = function( self, effect, effectType, x, y, dx, dy, wM, hM, onComplete )
		print("", "animeAttack "..self.id, "x"..x, "y"..y )
		tweenManager:addDelay( 0.5, true, onComplete )
        game:createEffect( effect, effectType, x, y, dx, dy, wM, hM )
	end,
	
	animeMove = function ( self, x, y, onComplete )
		print("", "animeMove "..self.id, "2"..x, "y2"..y )
		local exist = self.cfg.isGridBase and game:existsOnBoardByXY( self )
		if exist then game:removeFromBoardByXY( self ) end
		self.x2, self.y2 = x, y
		if exist then game:addToBoardByXY( self ) end
		if self == game.player then
			tweenManager:addTween( Tween.new( 0.3, self, { x1 = x, y1 = y }, 'linear' ), true, onComplete )
		else
			tweenManager:addTween( Tween.new( 0.5, self, { x1 = x, y1 = y }, 'inOutCubic' ), true, onComplete )
		end
	end,
	
	render = function( self, delta )
		local sprX, sprY = self.x1 * tileW + self.xOffset, self.y1 * tileW + self.yOffset
		if self.isShow == false then return end
		if self.spr_ ~= nil then
			spr(self.spr_, sprX, sprY, tileW * self.cfg.width, tileW * self.cfg.height)
		end
		if self == game.player or self.cfg.is_boss or self.cfg.owner ~= nil then
			-- tex( txtBank7, sprX, sprY, 32, 32, 32 * 13, 0, 32, 32 )
			-- self:showNumber( 3, 23, game.weapon.cfg.att )
			-- self:showNumber( 20, 23, game.sheid.cfg.energy_power )
		elseif self.cfg ~= nil and self.cfg.att ~= nil and self.cfg.is_terrain ~= nil and self.cfg.att > 0 and self.cfg.is_terrain == false then
			local color = self:getLevelColor()
			tex( txtBank7, sprX, sprY, 32, 32, 32 * 14, 0, 32, 32 )
			UI_ShowNumber( sprX + 3, sprY + 23, self.cfg.att, 1, color )
			UI_ShowNumber( sprX + 20, sprY + 23, self.cfg.hp, 1, color )
		elseif self.cfg ~= nil and self.cfg.is_terrain == false and self.cfg.is_pickup == false then
			tex( txtBank7, sprX, sprY, 32, 32, 32 * 15, 0, 32, 32 )
			UI_ShowNumber( sprX + 20, sprY + 23, self.cfg.hp, 1 )
		end
		if DEBUG_POSITION then
			rect(
				sprX, sprY, 
				sprX + tileW * self.cfg.width, sprY + tileW * self.cfg.height, 
				false,
				Color.new(255, 0, 0)
			)
		end
	end,

	getLevelColor = function(self)
		local level = 0
		if self == game.player then
			return Color.new( 255, 255, 255 )
		elseif self.cfg ~= nil and self.cfg.curLevel ~= nil then
			if self.cfg.is_boss then
				return Color.new( 255, 0, 0 )
			else
				level = self.cfg.curLevel
				if self.cfg.curLevel >= game.weapon.cfg.level + 4 then
					return Color.new( 255, 0, 0 )
				elseif self.cfg.curLevel >= game.weapon.cfg.level + 2 then
					return Color.new( 255, 100, 0 )
				elseif self.cfg.curLevel >= game.weapon.cfg.level then
					return Color.new( 255, 255, 0 )
				else
					return Color.new( 0, 255, 0 )
				end
			end
		end
	end,

	getTurnFinished = function(self)
		if DEBUG_FAST_MODE then return true end
		for k,v in ipairs( self.actions ) do
			if v.finished == false then 
				return false 
			end
		end
		return true
	end,

	setAllpos = function( self, x, y )
		self.x1 = x
		self.y1 = y
		local exist = self.cfg.isGridBase and game:existsOnBoardByXY( self )
		if exist then game:removeFromBoardByXY( self ) end
        self.x2 = x
		self.y2 = y
		if exist then game:addToBoardByXY( self ) end
	end,
	
	getRealPos = function(self)
		-- reutnr the position on screen
		return self.x1 * tileW + self.xOffset, self.y1 * tileW + self.yOffset
	end,

	getRenderPos = function(self)
		return self.x1, self.y1
	end,

	getDisplayPos = function(self)
		-- return the position where the sprite should start render
		return self.x2, self.y2
	end,

	getLogicPos = function(self)
		return self.x2, self.y2
	end,
})
