require 'code/class'
local Tween = require 'code/tween' -- See https://github.com/kikito/tween.lua.

function Equipment_canAfford( equipDef )
    Equipment_info( 'Equipment_canAfford:', equipDef )
    if equipDef.cost.crystal1 ~= nil and equipDef.cost.crystal1 > game.currency.crystal1 then return false end
    if equipDef.cost.crystal2 ~= nil and equipDef.cost.crystal2 > game.currency.crystal2 then return false end
    if equipDef.cost.crystal3 ~= nil and equipDef.cost.crystal3 > game.currency.crystal3 then return false end
    if equipDef.cost.crystal4 ~= nil and equipDef.cost.crystal4 > game.currency.crystal4 then return false end
    return true
end

function Equipment_cost( equipDef )
    Equipment_info( 'Equipment_cost:', equipDef )
    game.currency.crystal1 = game.currency.crystal1 - (equipDef.cost.crystal1 or 0)
    game.currency.crystal2 = game.currency.crystal2 - (equipDef.cost.crystal2 or 0)
    game.currency.crystal3 = game.currency.crystal3 - (equipDef.cost.crystal3 or 0)
    game.currency.crystal4 = game.currency.crystal4 - (equipDef.cost.crystal4 or 0)
end

function Equipment_info( surfix, equipDef)
    if DEBUG_WEAPON == false then return end
    local cost = ''
    if equipDef.cost then 
        cost = ( equipDef.cost.crystal1 or 'N' ) .. '-' .. ( equipDef.cost.crystal2 or 'N' ) .. '-' .. ( equipDef.cost.crystal3 or 'N' ) 
            .. '-' .. ( equipDef.cost.crystal4 or 'N' ) .. '-' .. ( equipDef.cost.crystal5 or 'N' )
    else
        cost = 'X-X-X-X-X-' .. ( equipDef.cost_category or 'N' ) .. '-' .. ( equipDef.cost_mix or 'N' )
    end
    print( surfix, ' ', equipDef.desc or 'N', ' Lv.' .. (#equipDef.level_up or 'N'), (equipDef.energy or 'N') .. '/' .. (equipDef.energy_max or 'N'), (equipDef.energy_power or 'N') .. '/' .. (equipDef.energy_power_max or 'N'),
        cost )
end

function Equipment_GetDetailDescription( equipDef )
    local result = ''..equipDef.id..'\n\n'
    if equipDef.etype == 'shield' then
        result = result .. '最大能量: '.. equipDef.energy_power_max..'\n\n'
            .. '可用升级: '.. #equipDef.level_up..'\n\n'

            .. equipDef.descDetails
    else
        result = result .. '正常攻击力: '.. equipDef.att..'\n'
            .. '低能量攻击力: '.. equipDef.min_att..'\n'
            .. '最大充能: '.. equipDef.energy_max..'\n'
            .. '充能消耗: '.. Equipment_GetCostDisplay( equipDef.recharge_cost, equipDef.energy_max ) ..'\n'
            .. '攻击范围: '.. '前方1格'..'\n\n'

            .. '可用升级: '.. #equipDef.level_up..'\n\n'

            .. equipDef.descDetails
    end
	return '[col=0xffffffff]'..result..'[/col]'
end

Equipment_GetLevelUpDisplay = function(level_up)
    return #level_up
end

Equipment_GetCostDisplay = function(cost, multiplier)
    local result = ''
    if multiplier == nil then
        multiplier = 1
    end
    if cost == nil then
        return ''
    end
    if cost.crystal1 ~= nil and cost.crystal1 > 0 then
        result = result .. '水晶I x'..cost.crystal1 * multiplier
    end
    if cost.crystal2 ~= nil and cost.crystal2 > 0 then
        result = result .. '水晶II x'..cost.crystal2 * multiplier
    end
    if cost.crystal3 ~= nil and cost.crystal3 > 0 then
        result = result .. '水晶III x'..cost.crystal3 * multiplier
    end
    if cost.crystal4 ~= nil and cost.crystal4 > 0 then
        result = result .. '水晶IV x'..cost.crystal4 * multiplier
    end
    if cost.crystal5 ~= nil and cost.crystal5 > 0 then
        result = result .. '水晶V x'..cost.crystal5 * multiplier
    end
    return result
end

Equipment = class({
    cfg = nil,
    spr = nil,

    ctor = function( self, equipDef )
        self.cfg = merge( EquipmentDefault, copy( equipDef ) )
        self.spr = Resources.load( self.cfg.img )
        self.spr:play('idle')
        Equipment_info( 'created', self.cfg )
    end,
	
	info = function(self, surfix )
        Equipment_info( surfix, self.cfg )
	end,

    render = function(self, x, y, dx, dy, zoom, angle )
        -- rotCenter = Vec2.new(0, 0)
		if self.spr ~= nil then
			spr(self.spr, ui.mox + x * 32 + dx, ui.moy + y * 32 + dy, 32 * zoom, 32 * zoom, angle)
        else
            debugtest('weapon not found')
        end
    end,
})