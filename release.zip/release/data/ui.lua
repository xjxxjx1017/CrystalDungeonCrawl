require 'code/class'
require 'libs/beGUI/beGUI'
require 'libs/beGUI/customizedTheme'
require 'code/util'
require 'equipments/equipment_def'
require 'equipments/equipment'

local P = beGUI.percent -- Alias of percent.

local tileSize = 32
local tileCount= 16
local totalH = 640
local totalW = 960
local mapPaddingW = 70
local mapPaddingH = 60
local mapOffsetX = totalW / 2 - tileSize * tileCount / 2
local mapOffsetY = mapPaddingH
local mapSize = tileSize * tileCount
local margin = 8 
local wLeft = mapOffsetX - mapPaddingW - margin * 2
local lineHeight = 30
local textPaddingTop = 0
local btnWUnit = 80
COLOR_TINT = Color.new( 0, 172, 186)
COLOR_TINT_50 = Color.new( 0, 172, 186, 128)
COLOR_DARK_BLUE = Color.new( 5, 26, 36)
COLOR_RED = Color.new( 255, 15, 0)
COLOR_ORANGE = Color.new( 243, 129, 4)
COLOR_ORANGE_50 = Color.new( 243, 129, 4, 128)
COLOR_PURPLE = Color.new( 148, 157, 224)
COLOR_WHITE = Color.new( 255, 255, 255)

UI = class({
    -- map position offsets
    mox = mapOffsetX,
    moy = mapOffsetY,

    popup = nil,
    onPopupConfirm = nil,
    widgets = nil,
    craft = nil,
    ispopup = false,
    showMask = false,

    chargeBtn = nil,
    craftBtn = nil,
    craftPanel = nil,
    crystalPowerBar = nil,
    equipmentBarRed = nil,
    equipmentBarOrange = nil,
    equipmentBar = nil,
    craftableHint = nil,

    curCraftableItemList = {},
    curCraftableItemListCanAfford = {},

    hasIntroPlayed = false,

    adjust = {400, 2, 2, 32, -16, -16},

    ctor = function(self)
    end,

    setup = function (self)

        self.crystalPowerBar = beGUI.ProgressBar.new(0, COLOR_TINT_50):setId('crystal_power'):anchor(0, 0):put(margin, margin):resize(P(100), lineHeight)
            :setMaxValue(0):setValue(0)
        self.equipmentBar = beGUI.ProgressBar.new(0, COLOR_TINT):setId('equipment'):anchor(0, 0):put(margin, lineHeight * 1 + margin * 2):resize(P(100), lineHeight)
            :setMaxValue(0):setValue(0)
        self.equipmentBarOrange = beGUI.ProgressBar.new(0, COLOR_ORANGE):setId('equipment_orange'):anchor(0, 0):put(margin, lineHeight * 1 + margin * 2):resize(P(50), lineHeight)
            :setMaxValue(0):setValue(0)
        self.equipmentBarRed = beGUI.ProgressBar.new(0, COLOR_RED):setId('equipment_red'):anchor(0, 0):put(margin, lineHeight * 1 + margin * 2):resize(P(25), lineHeight)
            :setMaxValue(0):setValue(0)
        self.chargeBtn = beGUI.Button.new('充能'):setId('button_r'):put( margin, lineHeight * 2 + margin * 3 ):resize(btnWUnit, lineHeight)
            :on('clicked', function (sender)
                print('充能')
                game:chargeWeapon()
                game.player.stun = game.player.stun + 1
            end )

        self.craftBtn = beGUI.Button.new('合成'):setId('button_space'):put(margin, totalH - margin - lineHeight):resize(btnWUnit * 2, lineHeight)
            :on('clicked', function (sender)
                print('合成')
                self:openCraftPanel()
                self.chargeBtn:setVisible( false )
                self.craftBtn:setVisible( false )
                self.craftableHint:setVisible( false )
            end)

        self.craftableHint = beGUI.Widget.new():put(0, totalH - (margin + lineHeight) * 2):resize(self.mox - mapPaddingW, lineHeight)

        local left = beGUI.Widget.new():put(0,0):resize(self.mox - mapPaddingW, totalH)
            :addChild( self.crystalPowerBar )
            :addChild( self.equipmentBar )
            :addChild( self.equipmentBarOrange )
            :addChild( self.equipmentBarRed )
            :addChild( self.chargeBtn )
            :addChild( self.craftBtn )
            :addChild( self.craftableHint )

        if DEBUG_ADJUST_PARTICLES then
            for i = 1,#self.adjust do
                left:addChild(
                    beGUI.InputBox.new('', 'Adjust'..i..": "..self.adjust[i])
                        :setId('inputbox')
                        :put(margin, lineHeight * ( 2 + i ) + margin * ( 3 + i ) )          -- X: 0, Y: 0.
                        :resize(P(100), lineHeight) -- W: 100%, H: 23.
                        :on('changed', function (sender, value)
                            self.adjust[i] = value
                            print('adjust value '..i.. ': '.. value)
                        end)
                )
            end
        end
    
        self.popup = beGUI.Widget.new():put(0, 0):resize(P(100), P(100))
        self.craft = beGUI.Widget.new():put(0, 0):resize(P(100), P(100))
        self.widgets = beGUI.Widget.new():put(0, 0):resize(P(100), P(100)):addChild(left)

        self:addCraftPanel()

        theme = customizedTheme.default()
    end,

    addCraftPanel = function(self)

        local exitButtonWidth = btnWUnit * 2
        local craftPanelRightSideOffset = btnWUnit * 2
        local craftPanelSizeW = mapSize + mapPaddingW
        local craftPanelSizeH = mapSize - lineHeight - margin
        local craftPanelSizeX = totalW / 2 - craftPanelSizeW / 2
        local craftPanelSizeY = mapPaddingH + margin
        craftPanelSizeW = craftPanelSizeW - craftPanelRightSideOffset
        rightPanelSizeW = craftPanelSizeX + craftPanelRightSideOffset - margin * 3

        self.craftPanel = beGUI.Widget.new():setId('craft'):put( craftPanelSizeX, craftPanelSizeY ):resize( craftPanelSizeW + rightPanelSizeW + margin, craftPanelSizeH )
        local itemListPanel = beGUI.List.new():setId('slot_items'):put(0, 0):resize(craftPanelSizeW, craftPanelSizeH)
        self.craftPanel:addChild( itemListPanel )

        self.craftPanel:addChild(
            beGUI.Button.new('Exit')
                :setId('exit')
                :put(craftPanelSizeW/2 - exitButtonWidth/2, craftPanelSizeH + margin)
                :resize(exitButtonWidth, lineHeight)
                :on('clicked', function (sender)
                    self.craftPanel:setVisible( false )
                    self.showMask = false
                    self.chargeBtn:setVisible( true )
                    self.craftBtn:setVisible( true )
                    self.craftableHint:setVisible( true )
                end)
        )

        local itemDetailPanel = beGUI.List.new():setId('slot_details'):put(craftPanelSizeW + margin, 0):resize(rightPanelSizeW, craftPanelSizeH)
            :addChild(
                beGUI.MultilineLabel.new( '' )
                    :setId('item_details')
                    :put(margin, margin)
                    :resize(rightPanelSizeW - margin * 2, craftPanelSizeH - margin * 2)
            )
        self.craftPanel:addChild( itemDetailPanel )

        self.craft:addChild( self.craftPanel )
        self.craftPanel:setVisible( false )

        self:updateCraftPanel(true)
    end,

    updateCraftableHint = function(self)
        self.craftableHint:clearChildren()
        for k,v in ipairs( self.curCraftableItemListCanAfford ) do
            local ee = merge( EquipmentDefault, copy( FindEquipmentById( v ) ) );
            local spr = Resources.load(ee.img);
            self.craftableHint:addChild( beGUI.PictureSprite.new( spr )
                :setId('icon'..k)
                :put((k-1) * (lineHeight + margin),0 )
                :resize(lineHeight, lineHeight)
			)
        end
    end,

    updateCraftPanel = function(self, isForce)
		if self.craft == nil then return end

        local craftPanelRightSideOffset = btnWUnit * 2
        local craftPanelSizeW = mapSize + mapPaddingW
        local craftPanelSizeH = mapSize
        local craftPanelSizeX = totalW / 2 - craftPanelSizeW / 2
        local craftPanelSizeY = mapPaddingH + margin
        craftPanelSizeW = craftPanelSizeW - craftPanelRightSideOffset

        local slotHeight = lineHeight + margin * 2
        local buttonWidth = btnWUnit
        local costWidth = btnWUnit * 1.5

        local itemList = game:filterEquipmentByCrafted()
        local equipped = { game.weapon.cfg.id, game.shield.cfg.id }
        local missingCategoryList = FindCategoriesMissing( itemList )
        for k,v in ipairs( missingCategoryList ) do
            table.insert( itemList, FindFirstInCategory( v ) )
        end

        local canAfford = {}
        for k = 1, #itemList, 1 do
            local v = FindEquipmentById( itemList[k] )
            local isNonEquippedNonCraftable = exists( equipped, v.id ) == false and exists( missingCategoryList, v.category ) and FindRequirement( v.id ) ~= nil
            if not exists( equipped, v.id ) and not isNonEquippedNonCraftable and Equipment_canAfford(v) then
                table.insert( canAfford, v.id )
            end
        end

        if #self.curCraftableItemList == #itemList and #self.curCraftableItemListCanAfford == #canAfford then
            return
        end
        self.curCraftableItemList = itemList
        self.curCraftableItemListCanAfford = canAfford

        local itemListPanel = self.craft:find( 'slot_items' )
        itemListPanel:clearChildren()

        local showCraftDetail = function(c)
            local details = self.craft:find('item_details')
            if c == nil then details:setValue( '' ) return end
            local d = FindEquipmentById( c )
			details:setValue( Equipment_GetDetailDescription(d) )
        end

        local ui_weaponbase = Resources.load('spr_ui/weaponbase.spr');
        ui_weaponbase:play('idle')
        for k,v in ipairs( itemList ) do
            local yOffset = (lineHeight + margin * 2) * (k-1)
            local ee = merge( EquipmentDefault, copy( FindEquipmentById( v ) ) );
            local spr = Resources.load(ee.img);
            spr:play('idle')
            itemListPanel
                -- :addChild(
                --     beGUI.PictureSprite.new( ui_weaponbase )
                --         :setId('slotui'..k)
                --         :put(margin, yOffset + margin + textPaddingTop)
                --         :resize(lineHeight, lineHeight)
                -- )
                :addChild(
                    beGUI.PictureSprite.new( spr )
                        :setId('icon'..k)
                        :put(margin, yOffset + margin + textPaddingTop)
                        :resize(lineHeight, lineHeight)
                )
                :addChild(
                    beGUI.MultilineLabel.new( 'XX' )
                        :setId('slot'..k..'_label')
                        :put(margin * 2 + lineHeight, yOffset + margin + textPaddingTop)
                        :resize(craftPanelSizeW - margin * 3 - buttonWidth - costWidth, lineHeight)
                        :setCapturable( true )
                        :on('hover-enter', function(sender) showCraftDetail(v) end)
                )
                :addChild(
                    beGUI.MultilineLabel.new( 'XX' )
                        :setId('slot'..k..'_cost_label')
                        :put(craftPanelSizeW - margin * 2 - buttonWidth - costWidth, yOffset + margin + textPaddingTop)
                        :resize(costWidth, lineHeight)
                        :setCapturable( true )
                        :on('hover-enter', function(sender) showCraftDetail(v) end)
                )
                :addChild( beGUI.Button.new('XX')
                    :setId('slot'..k..'_btn')
                    :put(craftPanelSizeW - margin - buttonWidth, yOffset + margin) 
                    :resize(buttonWidth, lineHeight)
                    :on('clicked', function (sender)
                        game:upgradeEquipment( FindEquipmentById( v ) )
                        game.player:changeState()
                        self:updateCraftPanel(false)
                    end)
                    :setCapturable( true )
                    :on('hover-enter', function(sender) showCraftDetail(v) end)
                )
                :setCapturable( true )
                :on('hover-enter', function(sender) showCraftDetail(nil) end)
        end


        for k = 1, #itemList, 1 do
            local v = FindEquipmentById( itemList[k] )
            local isNonEquippedNonCraftable = exists( equipped, v.id ) == false and exists( missingCategoryList, v.category ) and FindRequirement( v.id ) ~= nil
            local label = self.craft:find('slot'..k..'_label')
            local cost_label = self.craft:find('slot'..k..'_cost_label')
            local btn = self.craft:find('slot'..k..'_btn')
            if exists( equipped, v.id ) then
                -- show equipped item
                label:setVisible( true ):setCapturable( true )
                cost_label:setVisible( true ):setCapturable( true )
                btn:setVisible( false ):setCapturable( true )
                label:setValue( '[col=0x00ff00ff]' .. v.desc .. '[/col]' )
                cost_label:setValue( '[col=0x00ff00ff]已装备[/col]' )
            elseif isNonEquippedNonCraftable then
                -- non-equipped, non-craftable item
                label:setVisible( true ):setCapturable( false )
                cost_label:setVisible( true ):setCapturable( false )
                btn:setVisible( false ):setCapturable( false )
                label:setValue( '[col=0xffffff66]' .. v.desc .. '[/col]' )
                cost_label:setValue( '[col=0xffffff66]未解锁[/col]' )
            else
                if Equipment_canAfford( v ) then
                    label:setVisible( true ):setCapturable( true )
                    cost_label:setVisible( true ):setCapturable( true )
                    btn:setVisible( true ):setCapturable( true )
                    label:setValue( '[col=0xffffffff]' .. v.desc .. '[/col]' )
                    cost_label:setValue( '[col=0x2222ffff]'..Equipment_GetCostDisplay(v.cost)..'[/col]' )
                    btn:setValue( v.btn )
                else
                    label:setVisible( true ):setCapturable( true )
                    cost_label:setVisible( true ):setCapturable( true )
                    btn:setVisible( true ):setCapturable( true )
                    label:setValue( '[col=0xffffffff]' .. v.desc .. '[/col]' )
                    cost_label:setValue( '[col=0xff0000ff]'..Equipment_GetCostDisplay(v.cost)..'[/col]' )
                    btn:setValue( v.btn )
                end
            end
        end

        self:updateCraftableHint()
    end,
    
    render = function (self)
        local prog = self.widgets:get(1, 'crystal_power')
        prog:setValue( game.shield.cfg.energy_power )
        prog:setMaxValue( game.shield.cfg.energy_power_max )
    
        local v = game.weapon.cfg.energy
        self.equipmentBar:setValue( v )
        self.equipmentBar:setMaxValue( game.weapon.cfg.energy_max )

        if v > game.weapon.cfg.energy_max / 2 then
            v = game.weapon.cfg.energy_max / 2
        end
        self.equipmentBarOrange:setValue( v )
        self.equipmentBarOrange:setMaxValue( game.weapon.cfg.energy_max / 2 )

        if v > game.weapon.cfg.energy_max / 4 then
            v = game.weapon.cfg.energy_max / 4
        end
        self.equipmentBarRed:setValue( v )
        self.equipmentBarRed:setMaxValue( game.weapon.cfg.energy_max / 4 )

        text('能量(' .. game.weapon.cfg.energy .. '/' .. game.weapon.cfg.energy_max .. ')', margin * 2, lineHeight * 1 + margin * 2 + textPaddingTop, COLOR_WHITE)
    
        text('水晶I x' .. game.currency.crystal1, margin, totalH - ( margin + lineHeight) * 5, Color.new(255, 255, 255))
        text('水晶II x' .. game.currency.crystal2, margin, totalH - ( margin + lineHeight) * 4, Color.new(255, 255, 255))
        text('水晶III x' .. game.currency.crystal3, margin, totalH - ( margin + lineHeight) * 3, Color.new(255, 255, 255))
        text('水晶IV x' .. game.currency.crystal4, margin, totalH - ( margin + lineHeight) * 2, Color.new(255, 255, 255))
    
        if game.shield.cfg.energy_power == 0 then
            text('护盾：' .. game.shield.cfg.energy_power .. '/' .. game.shield.cfg.energy_power_max, margin * 2, margin + textPaddingTop, COLOR_RED)
        else
            text('护盾：' .. game.shield.cfg.energy_power .. '/' .. game.shield.cfg.energy_power_max, margin * 2, margin + textPaddingTop, COLOR_WHITE)
        end
    end,
    
    update = function (self, delta)

        if self.showMask then
			rect(0, 0, totalW, totalH, true, Color.new(40, 40, 40, 180))
        end

        font(theme['font'].resource)
        self.craft:update(theme, delta)
        self.widgets:update(theme, delta)
        font(lanapixel)

        self:render()

        if self.hasIntroPlayed == false then
            self.hasIntroPlayed = true
            game:intro()
        end

        if self.ispopup then
			rect(0, 0, totalW, totalH, true, Color.new(40, 40, 40, 180))
            font(theme['font'].resource)
            self.popup:update(theme, delta)
            font(lanapixel)
        end
    end,

    openCraftPanel = function ( self )
        self.showMask = true
        self.craftPanel:setVisible( true )
    end,

    openPopup = function ( self, title, messages, button, onConfirm )
        self.ispopup = true
        local onClick = function()
            print('Popup: remove')
            self.popup:clearChildren()
            self.ispopup = false
            onConfirm()
        end

        local box = beGUI.Widget.new()
            :setId('popupcontainer')
            :put(0, 0)     -- X: 27%, Y: 15.
            :resize(totalW - 30, totalH - 30) -- W: 45%, H: 290.
        for k,v in ipairs( messages ) do
            local font = 'font_white'
            if k == #messages then
                font = 'font_alert'
            end
            box:addChild( beGUI.Label.new(v, 'center', false, font)
                :put(0, totalH / 2 - lineHeight - #messages * lineHeight / 2 + k * lineHeight)
                :resize(totalW, lineHeight)
            )
        end
        box:addChild(
            beGUI.Button.new(button)
                :setId('popup_exit')
                :anchor(0, 0)      -- X: left, Y: bottom.
                :put((totalW - btnWUnit) / 2, totalH / 2 - lineHeight - #messages * lineHeight / 2 + #messages * lineHeight + lineHeight * 2)    -- X: -50%, Y: 0.
                :resize(btnWUnit, lineHeight) -- W: 48%, H: 23.
                :on('clicked', function (sender)
                    onClick()
                end)
        )
        self.popup:addChild( box )
    end
})

ui = UI.new()