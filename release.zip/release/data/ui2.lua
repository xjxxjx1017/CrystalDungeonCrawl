require 'code/class'
require 'libs/beGUI/beGUI'
require 'libs/beGUI/customizedTheme'
require 'code/util'
require 'code/keycode'

local P = beGUI.percent -- Alias of percent.

PosInRect = function( xx, yy, x, y, w, h )
    return xx > x and xx < x + w and yy > y and yy < y + h
end

cfgDefaultRectArea = { x = 0, y = 0, w = 480, h = 320, color = Color.new(40, 40, 40, 180) }
RectArea = class({
    ctor = function(self, cfg){
        self.cfg = merge( copy( cfgDefaultRectArea ), copy( cfg ) )
        ui:addUI( self )
    },

    render = function(self){
        rect(self.cfg.x, self.cfg.y, self.cfg.w, self.cfg.h, true, self.cfg.color)
    },

    update = function(self,delta){
    },

    kill = function(self){
        ui:removeUI( self )
    }
})

cfgDefaultClickArea = { x = 0, y = 0, w = 480, h = 320, onClick = nil, key = nil }
ClickArea = class({
    cfg = nil,
    area = nil,

    ctor = function(self, cfg){
        self.cfg = merge( copy( cfgDefaultClickArea ), copy( cfg ) )
        self.area = RectArea.new(self.cfg)
        ui:addUI( self )
    },

    render = function(self){
        rect(self.cfg.x, self.cfg.y, self.cfg.w, self.cfg.h, true, self.cfg.color)
    },

    update = function(self,delta){
        local tx, ty, tb1 = mouse()
        pressed = if self.cfg.key ~= nil then key( self.cfg.key ) else false end
        if space or ( tb1 and PosInRect(tx, ty, self.cfg.x, self.cfg.y, self.cfg.w, self.cfg.h ) ) then
            self.cfg.onClick()
        end
    },

    kill = function(self){
        ui:removeUI( self.area )
        ui:removeUI( self )
    }
})

cfgDefaultPopup = { message = 'test test test test test', color = Color.new(255, 255, 255), onConfirm = nil }
Popup = class({
    cfg = nil,
    area = nil,
    visible = false,

    ctor = function(self, cfg){
        self.cfg = merge( copy( cfgDefaultPopup ), copy( cfg ) )

        -- assuming the click area is the whole area
        self.area = ClickArea.new({ onClick = self.cfg.onConfirm })
    },

    render = function(self){
        if self.visible == false then return end 
        text( message, 10, 25, color )
    },

    update = function(self,delta){
    },

    kill = function(self){
        ui:removeUI( self.area )
        ui:removeUI( self )
    },

    onConfirm = function(self){
        self.cfg.onConfirm()
        self:kill()
    }
})

MainPanel = class({
    ul = {}

    ctor = function(sel){
        table.insert( ul, ClickArea.new( { 0 + self.margin, self.sH - self.margin, 100, self.lineHeight, onConfirm = function() 
            self.openCraftPanel()
        end }) )
    },

    render = function(self){
    },

    update = function(self,delta){
    }
})

UI2 = class({
    -- map position offsets
    mox = 190,
    moy = 30,
    uiList = {},
    margin = 5,
    lineHeight = 25,
    sH = 320,
    sW = 480,

    craft = nil,
    popup = nil,
    main = nil,

    ctor = function(self){

    },

    setup = function (self){
        self.main = MainPanel.new()
        self:addUI( self.main )
        self.craft = Popup.new({ message = 'CRAFT!' })
        self:addUI( self.craft )
        self.popup = Popup.new({ message = messages, onConfirm = onConfirm })
        self:addUI( self.popup )
    },

    render = function(self){
        for k,v in ipairs( self.uiList ) do
            v:render()
        end
    },

    update = function(self,delta){
        for k,v in ipairs( self.uiList ) do
            v:update(delta)
        end
    },

    openCraftPanel = function ( self )
    end,

    openPopup = function(self, title, messages, button, onConfirm){
    },

    addUI = function ( self, vv )
        table.insert( self.uiList, vv )
    end,
        
    removeUI = function ( self, vv )
        for k = #self.uiList, 1, -1 do
            local v = self.uiList[k]
            if vv == v then
                table.remove( self.uiList, k )
            end
        end
    end,
})