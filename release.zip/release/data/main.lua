require 'game'
require 'ui'
require 'map_generator'
require 'background'
require 'analysis'
require 'units/projectile'

-- resources
lanapixel = Font.new('fonts/LanaPixel.ttf', 26)   -- 中文像素字体，13 的倍数效果较好。
bank = nil

DEBUG = false -- full player vision, better weapon, more crystals
DEBUG_MORE_CRYSTAL = false
DEBUG_POSITION = false
DEBUG_MAP = false
DEBUG_WEAPON = false
DEBUG_UNIT = false
DEBUG_USE_TEST_LEVEL = false
DEBUG_RENDER_ORDER = false
DEBUG_FAST_MODE = false
DEBUG_FRAME = false
DEBUG_FRAME_RATE = false
DEBUG_HIDE_TERRAIN = false
DEBUG_UI_LAYOUT = false
DEBUG_ANALYSIS_LEVEL = false
DEBUG_ANALYSIS_ALL = false
DEBUG_LEVEL = false
DEBUG_KEYS = true -- enable cheat keys
DEBUG_ADJUST_PARTICLES = false -- use UI to adjust particle systems
TEST_MAP = 'level/test.map'

tileH = 32
tileW = 32
bg = Background.new()

initStep = 0

function setup()
	cls(Color.new(0,0,0))
	Canvas.main:resize(960, 640)

	math.randomseed(DateTime.ticks())

	font(lanapixel)
	sync()
end

function update(delta)
	if DEBUG_FRAME_RATE then
		if delta > 0.1 then
			warn('frame rate very low: '.. delta)
		elseif delta > 0.05 then
			warn('frame rate low: '.. delta)
		end
	end
	if DEBUG_ANALYSIS_ALL then
		if initStep == 0 then
			initStep = initStep + 1
			UnitMaster_Analysis_Export_All()
		end
	else
		if initStep == 0 then
			-- Load bg
			bg:setup()
			initStep = initStep + 1
			return
		elseif initStep == 1 then
			-- Load levels
			if DEBUG_MAP then
				mapGenerator:setup()
				mapGenerator.debug_module = mapGenerator:loadMapStructure( g )
			else
				mapGenerator:setup()
			end	
			initStep = initStep + 1
			return
		elseif initStep == 2 then
			-- Load map
			if DEBUG_MAP == false then
				game:setup()
			end	
			initStep = initStep + 1
			return
		elseif initStep == 3 then
			-- Load ui
			if DEBUG_MAP == false then
				ui:setup()
			end	
			initStep = initStep + 1
			return
		end
		
		bg:update(delta)
		if DEBUG_MAP then
			mapGenerator:printDebugModule()
		else
			game:update(delta)
			ui:update(delta)

			projectileManager:update(delta)
			projectileManager:render()
		end	
	end
end


