require 'units/unit_factory'
require 'code/util'

--[[

============================================================

1小时，也许20关，关卡内怪物的分布，及带给玩家的体验。叙述如下：
*先假象以每3关为一个分界线。总关卡与分界线可以以后调整*
1. 1~2 关（3分钟）
   * 上手、热身关。不熟悉的玩家可以探索游戏机制，熟悉的玩家可以积攒到一些稳定的水晶作资本。10%概率出现特殊版本的普通傻傻怪物。
2. 3~5 关（10分钟）
   * 需要小技巧的怪，小陷阱。
   * 每关出现boss的概率为20%，30%，100%。10%概率会出现强力的怪物。
3. 6~8 关（20分钟）
   * 需要小技巧的怪（类别2），陷阱。每一关都会有一处强力怪。10%概率会出现小技巧怪以下的特殊怪。
   * 假装玩家没有很care水晶的使用，50%的时候没有采用最高效率，则玩家的水晶应该在这一关开始吃紧，并且如果死亡了，不会积攒下多少水晶。
   * 如果玩家有过度升级装备，则虽然直到这关都会玩得很轻松，但从这时候开始，水晶会入不敷出。
4. 9~12 关（30分钟）
   * 需要技巧的怪，需要特别小心的陷阱。30%的怪会是强力怪，其余的是需要技巧的怪。10%概率会出现强力怪以下的特殊怪。
   * 每关出现boss的概率为20%，30%，100%。10%概率会出现强力的怪物。这关的boss会难缠很多。boss有20%几率会是强化版本。
   * 如果有特别的武器，在这几关会容易一些。如果没有特别注意武器的升级，则这机关会变得非常困难。正确的使用武器是这机关的关键。
5. 13~16 关（45分钟）
   * 阴险的陷阱到处都是，60%会是强力怪，其它时候是需要技巧的怪。20%概率会出现强力怪以下的特殊怪。
   * 所有事情做完美了，才能在这几关幸存。玩家对游戏的了解跟操作需要做到完美。
6. 17~20 关（1小时）
   * 过多的怪，过多的陷阱，不公平的敌我比例（比如20个史莱姆都在屏幕上）。20%概率会出现强力怪以下的特殊怪（由于怪的数量，这个概率可能会需要降低）。
   * 即使是完美主义的玩家，都需要碰运气，每一步都需要思考，稍不注意就会受到很严重的惩罚。失误2次大概就没机会了。
   * 绝对绝命的boss，打败boss需要几次死在它刀下的经验。boss有20%几率会是强化版本。

============================================================

玩家在每个关卡的武器升级预测曲线
玩家在每个关卡的护盾升级预测曲线
玩家在每个关卡所需累计水晶曲线

玩家技巧对累计水晶曲线的影响。使用武器等级越高，累积水晶越少。使用武器等级越低，累积水晶越多。

玩家使用标准武器，过低武器，过高武器，分别计算累计水晶。
保证两关，或三关内，累计水晶会回到正常值。也就是说，两三关内，水晶累计的差值，会等于武器等级水晶需求的差值。

每一关的risk曲线，根据玩家武器护盾等级计算。
越往后面对risk的预期值是越高的。新手30%到普通100%到老手500%，boss关有risk spike。
老手应该可以负担更高级的武器。

根据risk需求，跟水晶累计需求，计算需要生成多少怪物，以及什么样的怪物。

从上面分析可以看出，武器等级跟水晶累积有关。而怪物设计则是为了配置出上面的曲线。

]]

-- 加载样本武器与护盾, index代表等级
local sampleWeapon = {}
for i = 1,3 do
    table.insert( sampleWeapon, FindEquipmentById( '剑'..i ) )
end
for i = 1,10 do
    table.insert( sampleWeapon, FindEquipmentById( '硬铁剑'..i ) )
end
local sampleShield = {}
for i = 1,20 do
    table.insert( sampleShield, FindEquipmentById( '护盾'..i ) )
end
-- 20 关卡内，玩家装备的理想值。数值代表等级
local expectedWeaponLevel = { 1,2, 3,4,5, 5,6,6, 7,7,8,8, 8,9,9,9, 10,10,10,10 }  -- 玩家在每个关卡的武器升级预测曲线
local expectedShieldLevel = { 1,2, 3,4,5, 5,6,6, 7,7,8,8, 8,9,9,9, 10,10,10,10 }  -- 玩家在每个关卡的护盾升级预测曲线
local expectedCrystalSum = {}   -- 玩家在每个关卡所需累计水晶曲线
local sampleWeaponAtt = {}
local sampleShieldEnergy = {}
for i = 1, 20 do
    local temp___sum_multi = 10
    table.insert( expectedCrystalSum, ( SumCrystal( sampleWeapon[ expectedWeaponLevel[i] ].cost ) + SumCrystal( sampleShield[ expectedShieldLevel[i] ].cost ) ) * temp___sum_multi )
    table.insert( sampleWeaponAtt, sampleWeapon[ expectedWeaponLevel[i] ].att )
    table.insert( sampleShieldEnergy, sampleShield[ expectedShieldLevel[i] ].energy_power_max )
end

local expectedTotalRiskLevel = { 20 ,50 , 75 ,75 ,100 , 85 ,85 ,150 , 100 ,120 ,120 ,200 , 200 ,200 ,200 ,400 , 300 ,300 ,300 ,800  }
local expectedTotalUnitCount = { 12,12, 12, 12, 12, 15,15,15, 15, 15, 15, 15, 20,20,20,20, 20,20,20,20 }
local expectedUnitRiskLevel = {}
for i = 1, 20 do
    table.insert( expectedUnitRiskLevel, math.floor( expectedTotalRiskLevel[i] / expectedTotalUnitCount[i] ) )
end

local expectedUnitGain = {}
for i = 1, 20 do 
    table.insert( expectedUnitGain, math.floor( expectedCrystalSum[i] / expectedTotalUnitCount[i] * 10 ) / 10 )
end

Analysis_ExpectLevelGainAndRisk = function( level )
    return expectedCrystalSum[level], expectedTotalRiskLevel[level] / 100
end

local riskToleranceMin = 0.5
local riskToleranceMax = 2
local gainToleranceMin = 0.5
local gainToleranceMax = 2
local bossGainMultiplier = 5
local bossRiskMultiplier = 5

UnitMaster_Analysis_Export_All = function()

    print('')
    printArray( 'Analysis-CrystalSum', expectedCrystalSum )
    printArray( 'Analysis-WeaponLv', expectedWeaponLevel )
    printArray( 'Analysis-WeaponAtt', sampleWeaponAtt )
    printArray( 'Analysis-ShieldLv', expectedShieldLevel )
    printArray( 'Analysis-ShieldEnergy', sampleShieldEnergy )
    printArray( 'Analysis-UnitRisk', expectedUnitRiskLevel )
    printArray( 'Analysis-UnitGain', expectedUnitGain )
    print('')

    local allunits = UnitDef
    local summary = {}
    local levelUnitMap = {}
    for i = 1,20 do table.insert( levelUnitMap, {} ) end
    for kk,k in ipairs( UnitDefKey ) do
        local v = allunits[ k ]
        local c = merge( Config_Base, copy(v.cfg) )
        local line = '' .. c.img -- string.sub(c.img, 1,6)
        local line2 = '' .. c.img -- string.sub(c.img, 1,6)
        local line3 = '' .. c.img -- string.sub(c.img, 1,6)
        local line4 = '' .. c.img -- string.sub(c.img, 1,6)
        local line5 = '' .. c.img
        local level_min = 99
        local level_max = -1
        if k ~= GOAL and ( c.is_terrain == false or c.dropImg ~= nil ) then
            for i = 1,20 do
                local gain, risk = Analysis_UnitMaster( c, i )
                if c.analysis_is_boss then
                    gain = gain / bossGainMultiplier
                    risk = risk / bossRiskMultiplier
                end
                risk = risk -- to avoid 0 risk
                line = line .. '   ' .. string.format('%.1f', gain)
                line2 = line2 .. '   ' .. string.format('%.2f', risk)
                local allYes = true
                if gain <= expectedUnitGain[i] * gainToleranceMax and gain >= expectedUnitGain[i] * gainToleranceMin then 
                    line3 = line3 .. '   '..'Y'
                else 
                    line3 = line3 .. '   '..expectedUnitGain[i]
                    allYes = false
                end
                if risk == 0 then
                    line4 = line4 .. '   '.. '0'
                elseif risk * 100 <= expectedUnitRiskLevel[i] * riskToleranceMax and risk * 100 >= expectedUnitRiskLevel[i] * riskToleranceMin then 
                    line4 = line4 .. '   '..'Y'
                else 
                    line4 = line4 .. '   '.. string.format('%.2f', (expectedUnitRiskLevel[i] / 100)) 
                    allYes = false
                end
                if allYes then
                    level_min = math.min( level_min, i )
                    level_max = math.max( level_max, i )
                end
            end
            if risk ~= 0 or gain ~= 0 then 
                print( 'Analysis-Unit gainValue  ', line )
                print( 'Analysis-Unit gainTarget ', line3 )
                print( 'Analysis-Unit riskValue  ', line2 )
                print( 'Analysis-Unit riskTarget ', line4 )
                print('')
                if level_min ~= 99 or level_max ~= -1 then
                    table.insert( summary, line5 .. '   (level '..level_min.. ' - ' .. level_max .. ' )' )
                else
                    table.insert( summary, line5 .. '   (level '..level_min.. ' - ' .. level_max .. ' )' )
                end
                for i = level_min, level_max do
                    table.insert( levelUnitMap[i], c.img )
                end
            end
        end
    end
    print('')
    print('Units has valid setup for levels: ')
    printArrayAsLines( summary )
    print('')
    for k,v in ipairs( levelUnitMap ) do
        printArray( 'Level'..k, v )
    end
end

Analysis_UnitMaster = function( cfg, level )
    local hitC = cfg.analysis_hit_chance   -- how easy is it for this unit to attack the player
    local ambushC = cfg.analysis_ambush_chance -- how easy is it for this unit to ambush the player
    local att = sampleWeapon[expectedWeaponLevel[level]].att
    local att_cost = math.floor( SumCrystal( sampleWeapon[ expectedWeaponLevel[level] ].recharge_cost ) * 10 ) / 10 -- preserve 1 decimal
    local analysis_gain = SumCrystal(cfg)  -- how much to gain after killing this unit
    local analysis_kill_turn = math.ceil( cfg.hp / att )   -- how much does it cost to kill this unit, using level x weapon
    local analysis_kill_cost = analysis_kill_turn * att_cost
    local analysis_damage_potential = cfg.att * ambushC + cfg.att * hitC * analysis_kill_turn + cfg.analysis_child_damage * cfg.max_child / 2  -- how much damage is this unit likely to inflict to player, before it dies
    for k,v in ipairs( cfg.parts ) do
        analysis_damage_potential = analysis_damage_potential + v.att * v.analysis_ambush_chance + v.att * analysis_kill_turn * v.analysis_hit_chance
        analysis_gain = analysis_gain + SumCrystal( v )
    end
    local unit_per_map = expectedTotalUnitCount[level]
    local shield_level = level * 1
    local player_hp = sampleShield[ expectedShieldLevel[level] ].energy_power_max
    local perfectGain = math.floor( (analysis_gain - analysis_kill_cost) * 10 ) / 10 -- preserve 1 decimal
    local risk = math.floor( ( analysis_damage_potential / ( player_hp ) ) * 100 ) / 100 -- risk of fight a map full of this unit
    return perfectGain, risk
end

Analysis_Level_Equipments = function( level )
    return sampleWeapon[expectedWeaponLevel[level]].id, sampleShield[ expectedShieldLevel[level] ].id
end

--[[created 	装备：无	 Lv.0	0/0	0/0	N-N-N-N-N	
created 	装备：无	 Lv.0	0/0	0/0	N-N-N-N-N	

Analysis-CrystalSum	10, 17, 21, 25, 33, 33, 45, 45, 62, 62, 85, 85, 85, 117, 117, 117, 161, 161, 161, 161	
Analysis-WeaponLv	1, 2, 3, 4, 5, 5, 6, 6, 7, 7, 8, 8, 8, 9, 9, 9, 10, 10, 10, 10	
Analysis-WeaponAtt	2, 3, 4, 5, 6, 6, 7, 7, 8, 8, 9, 9, 9, 10, 10, 10, 11, 11, 11, 11	
Analysis-ShieldLv	1, 2, 3, 4, 5, 5, 6, 6, 7, 7, 8, 8, 8, 9, 9, 9, 10, 10, 10, 10	
Analysis-ShieldEnergy	20, 27, 34, 44, 55, 55, 68, 68, 83, 83, 100, 100, 100, 121, 121, 121, 144, 144, 144, 144	
Analysis-UnitRisk	1, 4, 6, 6, 8, 5, 5, 10, 6, 8, 8, 13, 10, 10, 10, 20, 15, 15, 15, 40	
Analysis-UnitGain	0.8, 1.4, 1.7, 2.0, 2.7, 2.2, 3.0, 3.0, 4.1, 4.1, 5.6, 5.6, 4.2, 5.8, 5.8, 5.8, 8.0, 8.0, 8.0, 8.0	

Analysis-Unit gainValue  slime   2.0   3.0   4.0   4.0   2.0   2.0   0.0   0.0   1.0   1.0   -1.0   -1.0   -1.0   -5.0   -5.0   -5.0   -11.0   -11.0   -11.0   -11.0	
Analysis-Unit gainTarget slime   0.8   1.4   1.7   Y   Y   Y   3.0   3.0   4.1   4.1   5.6   5.6   4.2   5.8   5.8   5.8   8.0   8.0   8.0   8.0	
Analysis-Unit riskValue  slime   0.18   0.10   0.05   0.04   0.03   0.03   0.02   0.02   0.01   0.01   0.00   0.00   0.00   0.00   0.00   0.00   0.00   0.00   0.00   0.00	
Analysis-Unit riskTarget slime   0.01   0.04   Y   Y   0.08   Y   0.05   0.10   0.06   0.08   0   0   0   0   0   0   0   0   0   0	

Analysis-Unit gainValue  sheep   1.0   2.0   2.0   2.0   1.0   1.0   0.0   0.0   -2.0   -2.0   -4.0   -4.0   -4.0   -8.0   -8.0   -8.0   -14.0   -14.0   -14.0   -14.0	
Analysis-Unit gainTarget sheep   Y   Y   Y   Y   2.7   2.2   3.0   3.0   4.1   4.1   5.6   5.6   4.2   5.8   5.8   5.8   8.0   8.0   8.0   8.0	
Analysis-Unit riskValue  sheep   0.00   0.00   0.00   0.00   0.00   0.00   0.00   0.00   0.00   0.00   0.00   0.00   0.00   0.00   0.00   0.00   0.00   0.00   0.00   0.00	
Analysis-Unit riskTarget sheep   0   0   0   0   0   0   0   0   0   0   0   0   0   0   0   0   0   0   0   0	

Analysis-Unit gainValue  cabage   2.0   3.0   4.0   5.0   3.0   3.0   1.0   1.0   -3.0   -3.0   -7.0   -7.0   -7.0   -4.0   -4.0   -4.0   -10.0   -10.0   -10.0   -10.0	
Analysis-Unit gainTarget cabage   0.8   1.4   1.7   2.0   Y   Y   3.0   3.0   4.1   4.1   5.6   5.6   4.2   5.8   5.8   5.8   8.0   8.0   8.0   8.0	
Analysis-Unit riskValue  cabage   0.50   0.29   0.17   0.09   0.07   0.07   0.05   0.05   0.04   0.04   0.04   0.04   0.04   0.01   0.01   0.01   0.01   0.01   0.01   0.01	
Analysis-Unit riskTarget cabage   0.01   0.04   0.06   Y   Y   Y   Y   Y   Y   Y   Y   0.13   0.10   0.10   0.10   0.20   0.15   0.15   0.15   0.40	

Analysis-Unit gainValue  fish   1.0   1.0   1.0   1.0   0.0   0.0   -1.0   -1.0   -3.0   -3.0   -5.0   -5.0   -5.0   -9.0   -9.0   -9.0   -15.0   -15.0   -15.0   -15.0	
Analysis-Unit gainTarget fish   Y   Y   Y   Y   2.7   2.2   3.0   3.0   4.1   4.1   5.6   5.6   4.2   5.8   5.8   5.8   8.0   8.0   8.0   8.0	
Analysis-Unit riskValue  fish   0.00   0.00   0.00   0.00   0.00   0.00   0.00   0.00   0.00   0.00   0.00   0.00   0.00   0.00   0.00   0.00   0.00   0.00   0.00   0.00	
Analysis-Unit riskTarget fish   0   0   0   0   0   0   0   0   0   0   0   0   0   0   0   0   0   0   0   0	

Analysis-Unit gainValue  bat   7.0   8.0   8.0   9.0   8.0   8.0   7.0   7.0   5.0   5.0   3.0   3.0   3.0   -1.0   -1.0   -1.0   -7.0   -7.0   -7.0   -7.0	
Analysis-Unit gainTarget bat   0.8   1.4   1.7   2.0   2.7   2.2   3.0   3.0   Y   Y   Y   Y   Y   5.8   5.8   5.8   8.0   8.0   8.0   8.0	
Analysis-Unit riskValue  bat   0.00   0.00   0.00   0.00   0.00   0.00   0.00   0.00   0.00   0.00   0.00   0.00   0.00   0.00   0.00   0.00   0.00   0.00   0.00   0.00	
Analysis-Unit riskTarget bat   0   0   0   0   0   0   0   0   0   0   0   0   0   0   0   0   0   0   0   0	

Analysis-Unit gainValue  spike   4.0   5.0   6.0   6.0   4.0   4.0   5.0   5.0   3.0   3.0   1.0   1.0   1.0   -3.0   -3.0   -3.0   -9.0   -9.0   -9.0   -9.0	
Analysis-Unit gainTarget spike   0.8   1.4   1.7   2.0   Y   Y   Y   Y   Y   Y   5.6   5.6   4.2   5.8   5.8   5.8   8.0   8.0   8.0   8.0	
Analysis-Unit riskValue  spike   0.64   0.40   0.25   0.19   0.15   0.15   0.09   0.09   0.07   0.07   0.06   0.06   0.06   0.05   0.05   0.05   0.04   0.04   0.04   0.04	
Analysis-Unit riskTarget spike   0.01   0.04   0.06   0.06   Y   0.05   Y   Y   Y   Y   Y   0.13   Y   Y   Y   0.20   0.15   0.15   0.15   0.40	

Analysis-Unit gainValue  digmouse   13.0   14.0   15.0   16.0   14.0   14.0   12.0   12.0   8.0   8.0   4.0   4.0   4.0   7.0   7.0   7.0   1.0   1.0   1.0   1.0	
Analysis-Unit gainTarget digmouse   0.8   1.4   1.7   2.0   2.7   2.2   3.0   3.0   Y   Y   Y   Y   Y   Y   Y   Y   8.0   8.0   8.0   8.0	
Analysis-Unit riskValue  digmouse   1.25   0.77   0.50   0.29   0.23   0.23   0.19   0.19   0.15   0.15   0.13   0.13   0.13   0.07   0.07   0.07   0.06   0.06   0.06   0.06	
Analysis-Unit riskTarget digmouse   0.01   0.04   0.06   0.06   0.08   0.05   0.05   Y   0.06   Y   Y   Y   Y   Y   Y   0.20   0.15   0.15   0.15   0.40	

Analysis-Unit gainValue  shygrass   1.0   2.0   2.0   2.0   1.0   1.0   0.0   0.0   -2.0   -2.0   -4.0   -4.0   -4.0   -8.0   -8.0   -8.0   -14.0   -14.0   -14.0   -14.0	
Analysis-Unit gainTarget shygrass   Y   Y   Y   Y   2.7   2.2   3.0   3.0   4.1   4.1   5.6   5.6   4.2   5.8   5.8   5.8   8.0   8.0   8.0   8.0	
Analysis-Unit riskValue  shygrass   0.00   0.00   0.00   0.00   0.00   0.00   0.00   0.00   0.00   0.00   0.00   0.00   0.00   0.00   0.00   0.00   0.00   0.00   0.00   0.00	
Analysis-Unit riskTarget shygrass   0   0   0   0   0   0   0   0   0   0   0   0   0   0   0   0   0   0   0   0	

Analysis-Unit gainValue  rock   11.0   12.0   13.0   14.0   12.0   12.0   10.0   10.0   6.0   6.0   2.0   2.0   2.0   5.0   5.0   5.0   -1.0   -1.0   -1.0   -1.0	
Analysis-Unit gainTarget rock   0.8   1.4   1.7   2.0   2.7   2.2   3.0   3.0   Y   Y   5.6   5.6   4.2   Y   Y   Y   8.0   8.0   8.0   8.0	
Analysis-Unit riskValue  rock   1.25   0.77   0.50   0.29   0.23   0.23   0.19   0.19   0.15   0.15   0.13   0.13   0.13   0.07   0.07   0.07   0.06   0.06   0.06   0.06	
Analysis-Unit riskTarget rock   0.01   0.04   0.06   0.06   0.08   0.05   0.05   Y   0.06   Y   Y   Y   Y   Y   Y   0.20   0.15   0.15   0.15   0.40	

Analysis-Unit gainValue  dog_gang   11.0   14.0   15.0   16.0   14.0   14.0   11.0   11.0   5.0   5.0   6.0   6.0   6.0   -2.0   -2.0   -2.0   -14.0   -14.0   -14.0   -14.0	
Analysis-Unit gainTarget dog_gang   0.8   1.4   1.7   2.0   2.7   2.2   3.0   3.0   Y   Y   Y   Y   Y   5.8   5.8   5.8   8.0   8.0   8.0   8.0	
Analysis-Unit riskValue  dog_gang   1.80   0.88   0.58   0.36   0.21   0.21   0.17   0.17   0.14   0.14   0.08   0.08   0.08   0.06   0.06   0.06   0.05   0.05   0.05   0.05	
Analysis-Unit riskTarget dog_gang   0.01   0.04   0.06   0.06   0.08   0.05   0.05   Y   0.06   Y   Y   Y   Y   Y   Y   0.20   0.15   0.15   0.15   0.40	

Analysis-Unit gainValue  wolf_gang   30.0   33.0   35.0   36.0   32.0   32.0   31.0   31.0   25.0   25.0   19.0   19.0   19.0   18.0   18.0   18.0   6.0   6.0   6.0   6.0	
Analysis-Unit gainTarget wolf_gang   0.8   1.4   1.7   2.0   2.7   2.2   3.0   3.0   4.1   4.1   5.6   5.6   4.2   5.8   5.8   5.8   Y   Y   Y   Y	
Analysis-Unit riskValue  wolf_gang   6.00   3.11   1.76   1.09   0.87   0.87   0.52   0.52   0.43   0.43   0.36   0.36   0.36   0.19   0.19   0.19   0.16   0.16   0.16   0.16	
Analysis-Unit riskTarget wolf_gang   0.01   0.04   0.06   0.06   0.08   0.05   0.05   0.10   0.06   0.08   0.08   0.13   0.10   Y   Y   Y   Y   Y   Y   0.40	

Analysis-Unit gainValue  spider_cave   -5.0   3.0   7.0   10.0   2.0   2.0   -4.0   -4.0   -15.0   -15.0   -22.0   -22.0   -22.0   -35.0   -35.0   -35.0   -65.0   -65.0   -65.0   -65.0	
Analysis-Unit gainTarget spider_cave   0.8   1.4   1.7   2.0   Y   Y   3.0   3.0   4.1   4.1   5.6   5.6   4.2   5.8   5.8   5.8   8.0   8.0   8.0   8.0	
Analysis-Unit riskValue  spider_cave   0.40   0.29   0.23   0.18   0.14   0.14   0.11   0.11   0.09   0.09   0.08   0.08   0.08   0.06   0.06   0.06   0.05   0.05   0.05   0.05	
Analysis-Unit riskTarget spider_cave   0.01   0.04   0.06   0.06   Y   0.05   0.05   Y   Y   Y   Y   Y   Y   Y   Y   0.20   0.15   0.15   0.15   0.40	

Analysis-Unit gainValue  shadow   34.0   36.0   37.0   37.0   36.0   36.0   34.0   34.0   30.0   30.0   26.0   26.0   26.0   18.0   18.0   18.0   6.0   6.0   6.0   6.0	
Analysis-Unit gainTarget shadow   0.8   1.4   1.7   2.0   2.7   2.2   3.0   3.0   4.1   4.1   5.6   5.6   4.2   5.8   5.8   5.8   Y   Y   Y   Y	
Analysis-Unit riskValue  shadow   3.04   1.65   1.08   0.83   0.52   0.52   0.42   0.42   0.34   0.34   0.28   0.28   0.28   0.23   0.23   0.23   0.20   0.20   0.20   0.20	
Analysis-Unit riskTarget shadow   0.01   0.04   0.06   0.06   0.08   0.05   0.05   0.10   0.06   0.08   0.08   0.13   0.10   0.10   0.10   Y   Y   Y   Y   Y	

Analysis-Unit gainValue  slime_king   1.2   2.4   3.2   3.6   2.4   2.4   1.6   1.6   0.2   0.2   -1.8   -1.8   -1.8   -3.6   -3.6   -3.6   -8.4   -8.4   -8.4   -8.4	
Analysis-Unit gainTarget slime_king   Y   Y   Y   Y   Y   Y   Y   Y   4.1   4.1   5.6   5.6   4.2   5.8   5.8   5.8   8.0   8.0   8.0   8.0	
Analysis-Unit riskValue  slime_king   0.18   0.10   0.06   0.04   0.03   0.03   0.02   0.02   0.01   0.01   0.01   0.01   0.01   0.01   0.01   0.01   0.01   0.01   0.01   0.01	
Analysis-Unit riskTarget slime_king   0.01   0.04   Y   Y   0.08   Y   0.05   0.10   0.06   0.08   0.08   0.13   0.10   0.10   0.10   0.20   0.15   0.15   0.15   0.40	

Analysis-Unit gainValue  crystal_ore   0.0   5.0   7.0   9.0   5.0   5.0   0.0   0.0   -5.0   -5.0   -13.0   -13.0   -13.0   -18.0   -18.0   -18.0   -36.0   -36.0   -36.0   -36.0	
Analysis-Unit gainTarget crystal_ore   0.8   1.4   1.7   2.0   Y   2.2   3.0   3.0   4.1   4.1   5.6   5.6   4.2   5.8   5.8   5.8   8.0   8.0   8.0   8.0	
Analysis-Unit riskValue  crystal_ore   0.00   0.00   0.00   0.00   0.00   0.00   0.00   0.00   0.00   0.00   0.00   0.00   0.00   0.00   0.00   0.00   0.00   0.00   0.00   0.00	
Analysis-Unit riskTarget crystal_ore   0   0   0   0   0   0   0   0   0   0   0   0   0   0   0   0   0   0   0   0	

Analysis-Unit gainValue  crystal1   1.0   1.0   1.0   1.0   1.0   1.0   1.0   1.0   1.0   1.0   1.0   1.0   1.0   1.0   1.0   1.0   1.0   1.0   1.0   1.0	
Analysis-Unit gainTarget crystal1   Y   Y   Y   Y   2.7   2.2   3.0   3.0   4.1   4.1   5.6   5.6   4.2   5.8   5.8   5.8   8.0   8.0   8.0   8.0	
Analysis-Unit riskValue  crystal1   0.00   0.00   0.00   0.00   0.00   0.00   0.00   0.00   0.00   0.00   0.00   0.00   0.00   0.00   0.00   0.00   0.00   0.00   0.00   0.00	
Analysis-Unit riskTarget crystal1   0   0   0   0   0   0   0   0   0   0   0   0   0   0   0   0   0   0   0   0	

Analysis-Unit gainValue  crystal2   2.0   2.0   2.0   2.0   2.0   2.0   2.0   2.0   2.0   2.0   2.0   2.0   2.0   2.0   2.0   2.0   2.0   2.0   2.0   2.0	
Analysis-Unit gainTarget crystal2   0.8   Y   Y   Y   Y   Y   Y   Y   4.1   4.1   5.6   5.6   4.2   5.8   5.8   5.8   8.0   8.0   8.0   8.0	
Analysis-Unit riskValue  crystal2   0.00   0.00   0.00   0.00   0.00   0.00   0.00   0.00   0.00   0.00   0.00   0.00   0.00   0.00   0.00   0.00   0.00   0.00   0.00   0.00	
Analysis-Unit riskTarget crystal2   0   0   0   0   0   0   0   0   0   0   0   0   0   0   0   0   0   0   0   0	

Analysis-Unit gainValue  crystal3   5.0   5.0   5.0   5.0   5.0   5.0   5.0   5.0   5.0   5.0   5.0   5.0   5.0   5.0   5.0   5.0   5.0   5.0   5.0   5.0	
Analysis-Unit gainTarget crystal3   0.8   1.4   1.7   2.0   Y   2.2   Y   Y   Y   Y   Y   Y   Y   Y   Y   Y   Y   Y   Y   Y	
Analysis-Unit riskValue  crystal3   0.00   0.00   0.00   0.00   0.00   0.00   0.00   0.00   0.00   0.00   0.00   0.00   0.00   0.00   0.00   0.00   0.00   0.00   0.00   0.00	
Analysis-Unit riskTarget crystal3   0   0   0   0   0   0   0   0   0   0   0   0   0   0   0   0   0   0   0   0	

Analysis-Unit gainValue  crystal5   8.0   8.0   8.0   8.0   8.0   8.0   8.0   8.0   8.0   8.0   8.0   8.0   8.0   8.0   8.0   8.0   8.0   8.0   8.0   8.0	
Analysis-Unit gainTarget crystal5   0.8   1.4   1.7   2.0   2.7   2.2   3.0   3.0   Y   Y   Y   Y   Y   Y   Y   Y   Y   Y   Y   Y	
Analysis-Unit riskValue  crystal5   0.00   0.00   0.00   0.00   0.00   0.00   0.00   0.00   0.00   0.00   0.00   0.00   0.00   0.00   0.00   0.00   0.00   0.00   0.00   0.00	
Analysis-Unit riskTarget crystal5   0   0   0   0   0   0   0   0   0   0   0   0   0   0   0   0   0   0   0   0	


Units has valid setup for levels: 
slime   (level 4 - 6 )	
sheep   (level 1 - 4 )	
cabage   (level 5 - 6 )	
fish   (level 1 - 4 )	
bat   (level 9 - 13 )	
spike   (level 5 - 10 )	
digmouse   (level 10 - 15 )	
shygrass   (level 1 - 4 )	
rock   (level 10 - 15 )	
dog_gang   (level 10 - 13 )	
wolf_gang   (level 17 - 19 )	
spider_cave   (level 5 - 5 )	
shadow   (level 17 - 20 )	
slime_king   (level 3 - 6 )	
crystal_ore   (level 5 - 5 )	
crystal1   (level 1 - 4 )	
crystal2   (level 2 - 8 )	
crystal3   (level 5 - 20 )	
crystal5   (level 9 - 20 )	

Level1	sheep, fish, shygrass, crystal1	
Level2	sheep, fish, shygrass, crystal1, crystal2	
Level3	sheep, fish, shygrass, slime_king, crystal1, crystal2	
Level4	slime, sheep, fish, shygrass, slime_king, crystal1, crystal2	
Level5	slime, cabage, spike, spider_cave, slime_king, crystal_ore, crystal2, crystal3	
Level6	slime, cabage, spike, slime_king, crystal2, crystal3	
Level7	spike, crystal2, crystal3	
Level8	spike, crystal2, crystal3	
Level9	bat, spike, crystal3, crystal5	
Level10	bat, spike, digmouse, rock, dog_gang, crystal3, crystal5	
Level11	bat, digmouse, rock, dog_gang, crystal3, crystal5	
Level12	bat, digmouse, rock, dog_gang, crystal3, crystal5	
Level13	bat, digmouse, rock, dog_gang, crystal3, crystal5	
Level14	digmouse, rock, crystal3, crystal5	
Level15	digmouse, rock, crystal3, crystal5	
Level16	crystal3, crystal5	
Level17	wolf_gang, shadow, crystal3, crystal5	
Level18	wolf_gang, shadow, crystal3, crystal5	
Level19	wolf_gang, shadow, crystal3, crystal5	
Level20	shadow, crystal3, crystal5	

]]