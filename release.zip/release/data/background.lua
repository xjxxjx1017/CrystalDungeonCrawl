
require 'code/class'
require 'code/keycode'
require 'code/util'
require 'units/object'
local Tween = require 'code/tween' -- See https://github.com/kikito/tween.lua.

BG_Forest = 6
BG_Mountain = 7
BG_River = 4

Background = class({
    backgroundObjectList = {},
    background = nil,
	backgroundMask = nil,

    setup = function(self)
    	self.background = Resources.load( 'level/background001.map' )
		self.backgroundMask = Resources.load('spr/background_mask.spr')
		self.backgroundMask:play('idle')
        for i = 0, 30 do
            for j = 0, 20 do
                local c = mget(self.background, i, j)
                if c == BG_Forest then
				    local o = Object.new( 'BG_Forest', i, j, { img = 'forest', width = 1, height = 1 }, 0, 0 )
                    table.insert( self.backgroundObjectList, o )
                elseif c == BG_Mountain then
				    local o = Object.new( 'BG_Mountain', i, j, { img = 'mountain', width = 1, height = 1 }, 0, 0 )
                    table.insert( self.backgroundObjectList, o )
                elseif c == BG_River then
				    local o = Object.new( 'BG_River', i, j, { img = 'river_bg', width = 1, height = 1 }, 0, 0 )
                    table.insert( self.backgroundObjectList, o )
                end
            end
        end
    end,

    update = function(self, delta)
        -- map( self.background, 0, 0 )
        for k,v in ipairs( self.backgroundObjectList ) do
            v:render( delta )
        end
		spr( self.backgroundMask, 0, 0, 960, 640 )
    end

}, object)