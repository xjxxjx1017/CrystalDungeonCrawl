require 'code/class'
require 'code/co'
require 'code/util'
require 'code/keycode'
require 'code/tweenmanager'
require 'units/player'
require 'units/unit_factory'
require 'units/unit_master'
require 'units/effect'
require 'equipments/equipment_def'
require 'equipments/equipment'

Chapters = {
    {
        intro = { '你醒来了，', '四周是很危险的丛林，', '你听到了附近黏黏的声音。', '现在的你虚弱而弱小，', '你感到心里升起一股热情', '（合成点什么来保护你自己吧）' },
        introBtn = '开始',
        clear = {'前面时一片森林，', '水晶力从茂密的丛林中蓬勃而出，', '那里会有些水晶矿吗？', '远处好像有什么巨大的东西', '正在逼近...'},
        clearBtn = '继续',
        lose = {'冰冷的黑暗将你吞没，', '没想到这片草地跟绵羊就这样成了你心里最后的景象。', '黑暗渐渐扩大，只留下最后一点小小的火焰', '（合成升级武器和护盾会让游戏更容易)'},
        loseBtn = '结束',
        mapData = nil,
    }
}

for i = 2, 19 do
    table.insert( Chapters, 
    {
        intro = {},
        introBtn = '',
        clear = {'关卡'..i, '（期待下一关吧）'},
        clearBtn = ' 继续 ',
        lose = {'关卡'..i, '失败'},
        loseBtn = '结束',
        mapData = nil,
    })
end

table.insert( Chapters, 
{
    intro = {},
    introBtn = '',
    clear = {'你成功了，走出了这片森林，', '这也许只是小小的第一步。', '但是世界的广大，纷繁奇异。', '又有多少未知的奇遇在前方等待。', '夜很长，一切才刚刚开始。', '（期待下一关吧）'},
    clearBtn = '胜利',
    lose = {'冰冷的黑暗将你吞没，', '没想到这片潮湿的森林就这样成了你心里最后的景象。', '黑暗渐渐扩大，不久什么都看不见了', '丛林深处巨大的黑影依稀可见', ''},
    loseBtn = '结束',
    mapData = nil,
})

Game = class({
    curUnitList = {},
    curEffectList = {},
    curStaticUnitList = {},
    
    coreLoop = nil,
    yard = nil,
    yardOriginal = nil,
    yard_ai = nil,
    player = nil,
	goal = nil,

    hint = nil,
    whitestar = nil,
    blind = nil,

    turn = 1,

    board = {},

    currency = copy( CRYSTALS ),
    weapon = Equipment.new( EQUIPMENT_DEFAULT ),
    shield = Equipment.new( EQUIPMENT_DEFAULT ),
    craftedEquipments = {},

    currentMapIndex = 0,

    uiDirty = false,

    ctor = function( self )
        self.currentMapIndex = 1
    end,

    intro = function (self)
        ui:openPopup( '开始', Chapters[self.currentMapIndex].intro, Chapters[self.currentMapIndex].introBtn, function() end )
    end,

    lose = function (self)
        ui:openPopup( '失败', Chapters[self.currentMapIndex].lose, Chapters[self.currentMapIndex].loseBtn,function() exit() end )
    end,

    win = function(self)
        ui:openPopup( '过关', Chapters[self.currentMapIndex].clear, Chapters[self.currentMapIndex].clearBtn,function() 
            if self.currentMapIndex == #Chapters then
                exit() 
            else 
                self.curUnitList = {}
                self.curStaticUnitList = {}
                self.currentMapIndex = self.currentMapIndex + 1
                self:loadStage()
            end
        end )
    end,

    reloadStage = function(self)
        self.curStaticUnitList = {}
        self.curUnitList = {}
        self:loadStage()
    end,

    loadStage = function(self)
        local mapData = nil
        if DEBUG_USE_TEST_LEVEL == false then
            mapData = mapGenerator:loadMapStructure( mapGenerator:generateMap( true ) )
            Chapters[self.currentMapIndex].mapData = mapData
        else
            mapData = Chapters[self.currentMapIndex].mapData
        end

        -- re-initialize the game board
        self.board = {}
        for i = 1, 16 do
            local newCol = {}
            table.insert( self.board, newCol )
            for j = 1, 16 do
                local newRow = {}
                table.insert( newCol, newRow )
            end
        end

        local sealList = {}
        local gainSum = 0
        local riskSum = 0
        for i = 0, 15 do
            for j = 0, 15 do
                local id = mget(mapData, i, j)

                local seal, multi = UnitFactory_GetUnitKeyAndCountFromSeal( id, self.currentMapIndex, 1 )
                if seal == nil then
                    -- if it's a normal unit or terrain
                    UnitFactory_CreateUnit( id, i, j, 1, math.random(1,10), nil )
                else
                    -- if it's a seal
                    table.insert( sealList, { id = UnitDef[seal].id, x = i, y = j, multi = multi, originalSeal = id } )
                    -- analysis
                    local c = UnitFactory_GetUnitFullDefById( UnitDef[seal].id )
                    local gain, risk = Analysis_UnitMaster( c, self.currentMapIndex )
                    gainSum = gainSum + gain * multi
                    riskSum = riskSum + risk * multi
                end
            end
        end

        print( '', 'MAP Gain', gainSum )
        print( '', 'MAP Risk', riskSum )

        local expectGain, expectRisk = Analysis_ExpectLevelGainAndRisk( self.currentMapIndex )
        print( '', 'Expect Gain', expectGain )
        print( '', 'Expect Risk', expectRisk )

        local adjustMulti = math.floor( expectGain / gainSum * 100 ) / 100
        print( '', 'Adjusted Multi', adjustMulti )

        local sortBySealType = function(a,b)
            return UnitFactory_FindSealTypePriorityById(a) < UnitFactory_FindSealTypePriorityById(b)
        end
        sealList = sort( sealList, sortBySealType )

        gainSum = 0
        riskSum = 0
        for k,v in ipairs( sealList ) do
            print( 'Seal: ' .. v.originalSeal )
            -- adjust unit count multiplier by level gain analysis
            local adjustedMulti = v.multi * adjustMulti
            if v.originalSeal == SEAL_BOSS.id and v.multi == 1 then
                adjustedMulti = 1
            end
            local tail = adjustedMulti - math.floor( adjustedMulti )
            if tail > 0 then
                local rand = math.random( 1, 100 ) / 100
                if rand < tail then
                    adjustedMulti = math.ceil( adjustedMulti )
                else
                    adjustedMulti = math.floor( adjustedMulti )
                end
            else
            end
            if adjustedMulti > 0 then
                print( '', 'UnitCreation', 'Multi == '..adjustedMulti, v.id, v.x, v.y )
                UnitFactory_CreateUnit( v.id, v.x, v.y, adjustedMulti, -1, nil )

                local c = UnitFactory_GetUnitFullDefById( v.id )
                local gain, risk = Analysis_UnitMaster( c, self.currentMapIndex )
                gainSum = gainSum + gain * adjustedMulti
                riskSum = riskSum + risk * adjustedMulti
            else
                UnitFactory_CreateUnit( UnitDef.FOREST.id, v.x, v.y, 1, -1, nil )
                warn( '', 'UnitCreation', 'Not Created', v.id, v.x, v.y )
            end
        end
        print( '', 'MAP Gain Adjusted', gainSum )
        print( '', 'MAP Risk Adjusted', riskSum )
        
        local sortByLayer = function(a, b)
            return a.cfg.layer < b.cfg.layer
        end
        print( '--------------------- before sort ---------------------' )
        if DEBUG_RENDER_ORDER then for k,v in ipairs( self.curUnitList ) do v:info( '#render#' ) end end
        self.curUnitList = sort( self.curUnitList, sortByLayer )
        print( '--------------------- after sort ---------------------' )
        if DEBUG_RENDER_ORDER then for k,v in ipairs( self.curUnitList ) do v:info( '#render#' ) end end
    end,

    setup = function ( self )
        
        self.hint = Resources.load('spr/star.spr')
        self.hint:play('idle', true, true)
        self.whitestar = Resources.load('spr/whitestar.spr')
        self.whitestar:play('idle', true, true)
        self.blind = Resources.load('spr/blind.spr')
        self.blind:play('idle', true, true)

        if DEBUG_UI_LAYOUT then
            UnitFactory_CreateUnit( PLAYER.id, 0, 0, 1, 1)
            UnitFactory_CreateUnit( GOAL.id, 15, 15, 1, 1)
        else
            if DEBUG_ANALYSIS_LEVEL == true then
                Chapters = {}
            end
    
            if DEBUG_USE_TEST_LEVEL then
                table.insert( Chapters, 1, {
                    intro = { '测试', '测试', '（合成点什么来保护你自己吧）' },
                    introBtn = '开始',
                    clear = {'测试', '测试', '测试...'},
                    clearBtn = '继续',
                    lose = {'测试', '测试', '（合成升级武器和护盾会让游戏更容易)'},
                    loseBtn = '结束',
                    mapData = Resources.load( TEST_MAP ),
                })
            elseif DEBUG_ANALYSIS_LEVEL then
                table.insert( Chapters, 1, {
                    intro = { '单位分析', '单位分析', '（...）' },
                    introBtn = '开始',
                    clear = {'单位分析', '单位分析', '单位分析...'},
                    clearBtn = '继续',
                    lose = {'单位分析', '单位分析', '（...)'},
                    loseBtn = '结束',
                    mapData = Resources.load( 'level/analysis_allunits.map' ),
                })
            end
    
            self:loadStage()
        end

        if DEBUG_WEAPON then
            for k,v in ipairs( EquipmentDefList ) do
                Equipment_info( 'EquipDef ', v )
            end
        end

        if DEBUG then
            self.currency.crystal1 = 50
            if self.player ~= nil then self.player.sight = 20 end
            game:upgradeEquipment( FindEquipmentById('剑3'), true )
            game:upgradeEquipment( FindEquipmentById('护盾3'), true  )
            game.player:changeState()
        else
            self.currency.crystal1 = 0
            game:upgradeEquipment( FindEquipmentById('剑1'), true )
            game:upgradeEquipment( FindEquipmentById('护盾1'), true  )
            game.player:changeState()
        end
		if DEBUG_MORE_CRYSTAL then
            self.currency.crystal1 = 50
            self.currency.crystal2 = 30
            self.currency.crystal3 = 20
            self.currency.crystal4 = 10
            game.player:changeState()
		end
        if DEBUG_USE_TEST_LEVEL then
            game.player.sight = 20
        end
    end,

    gameLoop = function(self, delta)
        -- update unit animations and check whether all their turn has finished
        local turnFinished = true
        local hasNextAction = false
		if self.player ~= nil then
	        self.player:update( delta )
	        turnFinished = turnFinished and self.player:getTurnFinished()
		end
        for k, v in ipairs(self.curUnitList) do
            v:update( delta )
            turnFinished = turnFinished and v:getTurnFinished()
        end
        if not( turnFinished ) or not( tweenManager:getAllFinished() ) then
            -- if one of the unit hasn't finished, then let them let them keep going
        else
			if self.player ~= nil then
	            -- otherwise, try start a player action first
	            hasNextAction = self.player:nextAction()
	            if not ( hasNextAction ) then
	                -- if the player has no action to perform, then all other units will stand by wait for the player
	            else
                    if DEBUG_RENDER_ORDER then for k,v in ipairs( game.curUnitList ) do v:info( '#render#' ) end end
                    print( '--------------------- turn ' .. self.turn .. ' ---------------------' )
                    self.turn = self.turn + 1
	                -- otherwise, if the player moved, all other units will try to act, if they have any intent to do so
	                for k,v in ipairs( self.curUnitList ) do
	                    if v.nextAction ~= nil then
	                        v:nextAction()
	                    end
	                end
	            end
			end
        end
    end,

    update = function (self, delta)

        if DEBUG_KEYS then
            --[[
                R： 重新生成本关卡
                I：上一关卡
                O：下一关卡
                E： 装备至该关卡标准
            ]]
            if keyp(KeyCode.R) then
                print('', '重新生成地图，等级'..self.currentMapIndex)
                self:reloadStage()
            end
            if keyp(KeyCode.O) then
                self.currentMapIndex = self.currentMapIndex + 1
                if self.currentMapIndex > #Chapters then
                    self.currentMapIndex = #Chapters
                end
                print('', '切换地图等级，等级'..self.currentMapIndex)
            end
            if keyp(KeyCode.I) then
                self.currentMapIndex = self.currentMapIndex - 1
                if self.currentMapIndex < 1 then
                    self.currentMapIndex = 1
                end
                print('', '切换地图等级，等级'..self.currentMapIndex)
            end
            if keyp(KeyCode.E) then
                local weapon, shield = Analysis_Level_Equipments( self.currentMapIndex )
                self:upgradeEquipment( FindEquipmentById(weapon), true )
                self:upgradeEquipment( FindEquipmentById(shield), true )
                game.player:changeState()
                print('', '切换玩家装备到预期，等级'..self.currentMapIndex)
            end
            if keyp(KeyCode.D) then
                -- firing a dropping crystal
                local xx, yy = mouse(1)
                Projectile_DropCrystals( xx, yy, 10, { crystal1 = 1 } )
            end
            if keyp(KeyCode.M) then
                self.currency.crystal1 = self.currency.crystal1 + 50
                self.currency.crystal2 = self.currency.crystal2 + 30
                self.currency.crystal3 = self.currency.crystal3 + 20
                self.currency.crystal4 = self.currency.crystal4 + 10
                game.player:changeState()
            end
        end

        tweenManager:update(delta)

        self:gameLoop(delta)

        local newlySeenGrid = {}

        for k, v in ipairs(self.curStaticUnitList) do
			if self.player ~= nil then
	            local vx, vy = v:getLogicPos()
	            if self.player:isInSight( vx, vy ) then
                    local id = ''..vx..' '..vy
                    if v.cfg.seen == false and not exists( newlySeenGrid, id ) and v.cfg.is_terrain then
                        table.insert( newlySeenGrid, id )
                    end
                    v.cfg.seen = true
	                v:render( delta )
                elseif v.cfg.is_terrain and v.cfg.seen then
	                v:render( delta )
                    spr( self.blind, vx * 32 + ui.mox, vy * 32 + ui.moy, 32, 32)
                elseif v.cfg.is_terrain then
                    spr( self.whitestar, vx * 32 + ui.mox, vy * 32 + ui.moy, 32, 32)
                end
			else 
				v:render(delta)
			end
        end
		
        for k, v in ipairs(self.curUnitList) do
			if self.player ~= nil then
	            local vx, vy = v:getLogicPos()
	            v:update( delta )
	            if self.player:isInSight( vx, vy ) then
                    local id = ''..vx..' '..vy
                    if v.cfg.seen == false and not exists( newlySeenGrid, id ) and v.cfg.is_terrain then
                        table.insert( newlySeenGrid, id )
                    end
                    v.cfg.seen = true
	                v:render( delta )
                elseif v.cfg.is_terrain and v.cfg.seen then
	                v:render( delta )
                    spr( self.blind, vx * 32 + ui.mox, vy * 32 + ui.moy, 32, 32)
                elseif v.cfg.is_terrain then
                    spr( self.whitestar, vx * 32 + ui.mox, vy * 32 + ui.moy, 32, 32)
                end
			else 
				v:update(delta)
				v:render(delta)
			end
        end

		if self.player ~= nil then
        	self.player:render( delta )
            local px, py = self.player:getRenderPos()
            self.weapon:render( px, py, 32 * 0.5, 32 * 0.5, 0.5, math.pi * 0)
		end

        if game.shield.cfg.energy_power < game.shield.cfg.energy_power_max then
            for k, v in ipairs( newlySeenGrid ) do
                local pos = mysplit( v )
                local posX, posY = ui.mox + 32 * pos[1] + math.random(0, 16), ui.moy + 32 * pos[2] + math.random(0, 16)
                local amount = math.ceil( game.shield.cfg.energy_power_max / 10 )
                Projectile_DropShield( posX, posY, 1, amount )
            end
        end

        tweenManager:render()

        for k, v in ipairs(self.curEffectList) do
            v:render( delta )
        end

        if DEBUG_LEVEL and Chapters[self.currentMapIndex].mapData ~= nil then
            map( Chapters[self.currentMapIndex].mapData, 0, ui.moy + 40 )
        end

        if self.uiDirty then
            ui:updateCraftPanel(false)
            self.uiDirty = false
        end
    end,

    upgradeEquipment = function ( self, equipDef, isFree )
        print('打造 ' .. equipDef.desc) 
        isFree = isFree == true or false
        local n = Equipment.new( equipDef )
        local lastEquipment = ''
        if isFree == false then
            if not( Equipment_canAfford( n.cfg ) ) then return end
            Equipment_cost( equipDef )
        end
        if equipDef.etype == 'weapon' then
            self.weapon:info( 'upgradeEquipment:Old' )
            lastEquipment = self.weapon.cfg
            local used = self.weapon.cfg.energy_max - self.weapon.cfg.energy
            self.weapon = n
            self.weapon.cfg.energy = self.weapon.cfg.energy_max - used
			-- below code can fix ui problem and create game hacks
			-- if self.weapon.cfg.energy < 0 then self.weapon.cfg.energy = 0 end
            self.weapon:info( 'upgradeEquipment:NewAdjusted' )
        else
            self.shield:info( 'upgradeEquipment:Old' )
            lastEquipment = self.shield.cfg
            local used = self.shield.cfg.energy_power_max - self.shield.cfg.energy_power
            self.shield = n
            self.shield.cfg.energy_power = self.shield.cfg.energy_power_max - used
            self.shield:info( 'upgradeEquipment:NewAdjusted' )
        end
    end,

    filterEquipmentByCrafted = function( self )
        local basic = { game.shield.cfg.id, game.weapon.cfg.id }
        return FilterEquipmentByCrafted( basic )
    end,

    searchAdjustMap = function ( self, m, id, x, y )
        local r = {}
        for i = 1, 8 do
            local xx = x + adjust8X[i]
            local yy = y + adjust8Y[i]
            local vv = mget(m, xx, yy)
            if id == vv then
                table.insert( r, { x = xx, y = yy } )
            end
        end
        return r
    end,

    getEmptySpaceInRange = function ( self, x, y, rangemin, rangemax )
        local result = {}
        for i = -rangemax,rangemax do
            for j = -rangemax,rangemax do
                if (x+i)*(x+i) + (y+j)*(y+j) <= rangemin * rangemin then
				else 
	                if self:getBlocked( x + i, y + j ) == nil and self:isPlayer( x + i, y + j ) == false then
	                    table.insert( result, {x = x+i, y = y+j } )
	                end
				end
            end
        end
        return result
    end,
        
    getBlocked = function ( self, x, y )
        for k, v in ipairs(game:getBoard(x, y)) do
            if v.isShow == true and v.cfg.blocking == true then
                return v
            end
        end
        return nil
    end,

    getFirstBlocked = function( self, x, y, lst )
        for kk,vv in ipairs( lst ) do
            local blockedBy = self:getBlocked( x + vv.x, y + vv.y )
            if blockedBy ~= nil then 
				return blockedBy, vv.x, vv.y
			end
        end
        return nil, x, y
    end,

    convertPosToFacingDirection = function( self, facingDirection, posInUpDirection )
        local upDir = { x = 0, y = 1 }
        if facingDirection.x == 1 and facingDirection.y == 0 then
            return { x = posInUpDirection.y, y = -posInUpDirection.x }
		end
        if facingDirection.x == 0 and facingDirection.y == -1 then
            return { x = -posInUpDirection.x, y = -posInUpDirection.y }
		end
        if facingDirection.x == -1 and facingDirection.y == 0 then
            return { x = -posInUpDirection.y, y = posInUpDirection.x }
		end
        if facingDirection.x == 0 and facingDirection.y == 1 then
            return { x = posInUpDirection.x, y = posInUpDirection.y }
		end
        return { x = 0, y = 0 }
    end,

    searchPlayer = function ( self, lst, x, y )
        local a = filter( lst, function(l) return self:isPlayer( l.x + x, l.y + y ) end )
        if #a > 0 then 
            return a[1] 
        else 
            return nil 
        end
    end,

    getUnitAtPos = function( self, x, y )
        return self:getBoard(x, y)
    end,

    getUnitsInRange = function(self, x, y, range )
        local rlt = {}
        for i = x - range, x + range do
            for j= y - range, y + range do
                for k, v in ipairs(game:getBoard(i, j)) do
                    local vx, vy = v:getLogicPos()
                    if (vx-x)*(vx-x)+(vy-y)*(vy-y) <= range * range then
                        table.insert( rlt, v )
                    end
                end
            end
        end
        return rlt
    end,

    isPlayerInRange = function(self, x, y, range )
        local vx, vy = self.player:getLogicPos()
        return (vx-x)*(vx-x)+(vy-y)*(vy-y) <= range * range
    end,
    
    isPlayer = function ( self, x, y )
        local px, py = self.player:getLogicPos()
        return px == x and py == y
    end,
        
    removeUnit = function ( self, vv )
        if vv.cfg.is_static then
            for k = #self.curStaticUnitList, 1, -1 do
                local v = self.curStaticUnitList[k]
                if vv == v then
                    table.remove( self.curStaticUnitList, k )
                end
            end
        else
            for k = #self.curUnitList, 1, -1 do
                local v = self.curUnitList[k]
                if vv == v then
                    table.remove( self.curUnitList, k )
                end
            end
        end
        self:removeFromBoardByXY( vv )
    end,

    addUnit = function( self, u )
        if u.cfg.is_static then
            table.insert( self.curStaticUnitList, u )
        else
            table.insert( self.curUnitList, u )
        end
        self:addToBoardByXY(u)
    end,

    removeFromBoardByXY = function( self, u )
        local x,y = u:getLogicPos()
        if x < 0 or x > 15 or y < 0 or y > 15 then error( 'board position not found '..'x'..x..' y'..y..' ' .. Debug.trace() ) end
        remove( self:getBoard(x, y), u )
    end,

    addToBoardByXY = function( self, u )
        local x,y = u:getLogicPos()
        if x < 0 or x > 15 or y < 0 or y > 15 then error( 'board position not found '..'x'..x..' y'..y..' ' .. Debug.trace() ) end
        table.insert( self:getBoard(x, y), u )
    end,

    existsOnBoardByXY = function( self, u )
        if self.board == nil or #self.board == 0 then return false end
        local x,y = u:getLogicPos()
        return exists( self:getBoard(x, y), u )
    end,

    getBoard = function( self, x, y )
        local xx, yy = x+1, y+1
        if xx < 1 or xx > 16 or yy < 1 or yy > 16 then return {} end
		if self.board == nil or self.board[xx] == nil then
            error('board position not valid. '..'x'..xx..' y'..yy..' ' .. Debug.trace())
		end
        return self.board[xx][yy]
    end,
    
    chargeWeapon = function (self)
        local dx = self.weapon.cfg.energy_max - self.weapon.cfg.energy
        if self.currency.crystal1 < dx then
            dx = self.currency.crystal1
        end
        self.weapon.cfg.energy = self.weapon.cfg.energy + dx
        self.currency.crystal1 = self.currency.crystal1 - dx
        self.player:changeState()
    end,
    
    createEffect = function ( self, img, state, x, y, dx, dy, wM, hM, callback )
        local e = nil
        local removeEffect = function ()
            table.remove( self.curEffectList, tablefind( self.curEffectList, e ) )
            if callback ~= nil then
                callback()
            end
        end
        if state ~= '' then
            e = EffectAtt.new( img, state, x, y, dx, dy, wM, hM, removeEffect )
        else
            e = EffectFolder.new( img, x, y, dx, dy, wM, hM, removeEffect )
        end
        table.insert( self.curEffectList, e )
    end,

    curAtt = function (self, blocker)
        local att_total = -1
        if blocker.cfg.is_terrain then
            att_total = self.weapon.cfg.att_terrain
        elseif self.weapon.cfg.energy > 0 then
            att_total = self.weapon.cfg.att
        else
            att_total = self.weapon.cfg.min_att
        end
        return att_total
    end,
})

game = Game.new()