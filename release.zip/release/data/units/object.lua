require 'code/class'
require 'code/keycode'
require 'code/util'
local Tween = require 'code/tween' -- See https://github.com/kikito/tween.lua.


--[[
	Object is a class that handles basic grid based objects ( more likely to be units ). 
	It has two pairs of position values, one for rendering and the other for logic.
	It can play out the animation of attack and move
	It handles the tweens of attack and move, can check whether the unit's turn is finished.
	It also holds the units config
]]
Object = class({
	x1 = 0, -- anime posX
	y1 = 0, -- anime posY
	x2 = 0, -- logic posX
	y2 = 0, -- logic posY
	spr_ = nil,
	sprLevel = nil,
	tw = nil,
	actions = {},
	id = '',
	cfg = nil,
	isShow = true,
	xOffset = 0,
	yOffset = 0,
	
	ctor = function ( self, id, x, y, cfg, xOffset, yOffset )
		self.id = id .. '.' .. x .. '.' .. y
		self.cfg = cfg or Unitcfg.new()
		self:setAllpos( x, y )
		self.xOffset = xOffset
		self.yOffset = yOffset
		if self.cfg.img ~= nil then
			imgSrc = 'spr/' .. self.cfg.img ..  '.spr'
			self.spr_ = Resources.load(imgSrc)
			self.spr_:play('idle')
		end
		-- if self.cfg.curLevel > 0 or self.cfg.curLevel < 11 then
		-- 	self.sprLevel = Resources.load('spr_ui/numbers')
		-- 	self.sprLevel:play(''.. (self.cfg.curLevel%10))
		-- end
	end,

	update = function( self, delta )
		if self.tw ~= nil then
			self.tw:update(delta)
		end
		for k,v in ipairs( self.actions ) do
			v:update(delta)
		end
		for k = #self.actions, 1, -1 do
			local vv = self.actions[k]
			if vv.finished == true then
				table.remove( self.actions, k )
			end
		end
	end,

	animeAttack = function( self, effect, effectType, x, y, dx, dy, wM, hM, onComplete )
		print("", "animeAttack "..self.id, "x"..x, "y"..y )
		tweenManager:addDelay( 0.5, true, onComplete )
        game:createEffect( effect, effectType, x, y, dx, dy, wM, hM )
	end,
	
	animeMove = function ( self, x, y, onComplete )
		print("", "animeMove "..self.id, "2"..x, "y2"..y )
		local exist = self.cfg.isGridBase and game:existsOnBoardByXY( self )
		if exist then game:removeFromBoardByXY( self ) end
		self.x2, self.y2 = x, y
		if exist then game:addToBoardByXY( self ) end
		tweenManager:addTween( Tween.new( 0.5, self, { x1 = x, y1 = y }, 'inOutCubic' ), true, onComplete )
	end,
	
	render = function( self, delta )
		if self.isShow == false then return end
		if self.spr_ ~= nil then
			spr(self.spr_, self.x1 * tileW + self.xOffset, self.y1 * tileW + self.yOffset, tileW * self.cfg.width, tileW * self.cfg.height)
		end
		if self.cfg.curLevel ~= nil and self.cfg.curLevel > 0 then
			local color = Color.new( 255, 0, 0 )
			if self.cfg.curLevel > 0 and self.cfg.curLevel < 4 then
				color = Color.new( 0, 255, 0 )
			elseif self.cfg.curLevel > 3 and self.cfg.curLevel < 7 then
				color = Color.new( 255, 100, 100 )
			elseif self.cfg.curLevel > 6 and self.cfg.curLevel < 9 then
				color = Color.new( 255, 50, 50 )
			end
			-- spr(self.sprLevel, self.x1 * tileW + self.xOffset, self.y1 * tileW + self.yOffset, tileW * self.cfg.width, tileW * self.cfg.height)
        	text('' ..self.cfg.curLevel, self.x1 * tileW + self.xOffset, self.y1 * tileW + self.yOffset, color)
		end
		if DEBUG_POSITION then
			rect(
				self.x1 * tileW + self.xOffset, self.y1 * tileW + self.yOffset, 
				self.x1 * tileW + self.xOffset + tileW * self.cfg.width, self.y1 * tileW + self.yOffset + tileW * self.cfg.height, 
				false,
				Color.new(255, 0, 0)
			)
		end
	end,

	getTurnFinished = function(self)
		if DEBUG_FAST_MODE then return true end
		for k,v in ipairs( self.actions ) do
			if v.finished == false then 
				return false 
			end
		end
		return true
	end,

	setAllpos = function( self, x, y )
		self.x1 = x
		self.y1 = y
		local exist = self.cfg.isGridBase and game:existsOnBoardByXY( self )
		if exist then game:removeFromBoardByXY( self ) end
        self.x2 = x
		self.y2 = y
		if exist then game:addToBoardByXY( self ) end
	end,
	
	getRealPos = function(self)
		-- reutnr the position on screen
		return self.x1 * tileW + self.xOffset, self.y1 * tileW + self.yOffset
	end,

	getRenderPos = function(self)
		return self.x1, self.y1
	end,

	getDisplayPos = function(self)
		-- return the position where the sprite should start render
		return self.x2, self.y2
	end,

	getLogicPos = function(self)
		return self.x2, self.y2
	end,
})
