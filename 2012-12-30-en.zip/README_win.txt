# Windows

The executable binaries are under the "x64" and "x86" directories for 64-bit
and 32-bit architectures respectively. It requires VC++ 2015 Runtime.

The "play.exe" is an optional launcher which determines to launch either x64 or
x86 binary automatically on end user's system. It requires .Net Framework 4.5.
